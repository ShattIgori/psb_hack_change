#!/bin/bash

# Упрощенный скрипт для запуска LMS и Telegram бота
# Используется для локального тестирования и сдачи экспертам

# 1. Активация виртуального окружения
if [ -d "venv" ]; then
    source venv/bin/activate
else
    echo "Виртуальное окружение 'venv' не найдено. Пожалуйста, запустите 'pip install -r requirements.txt' и 'python3 -m venv venv' перед запуском."
    exit 1
fi

# 2. Запуск LMS платформы в фоновом режиме
echo "🚀 Запуск LMS платформы..."
cd lms_platform
python3 app.py &
LMS_PID=$!
cd ..

# 3. Ожидание запуска LMS (необязательно, но полезно)
echo "⏳ Ожидание 5 секунд для запуска LMS..."
sleep 5

# 4. Запуск Telegram бота
echo "🤖 Запуск Telegram бота..."
cd telegram_bot
python3 bot.py &
BOT_PID=$!
cd ..

echo "✅ LMS и Telegram бот запущены в фоновом режиме."
echo "LMS PID: $LMS_PID"
echo "Bot PID: $BOT_PID"
echo "Для остановки используйте команду: kill $LMS_PID $BOT_PID"

# 5. Ожидание завершения
wait $LMS_PID $BOT_PID
