#!/bin/bash

# Startup script for LMS Platform

echo "=========================================="
echo "Starting LMS Platform..."
echo "=========================================="

# Navigate to the LMS platform directory
cd "$(dirname "$0")/lms_platform"

# Check if virtual environment exists
if [ ! -d "../venv" ]; then
    echo "Virtual environment not found. Please run: python3 -m venv venv"
    exit 1
fi

# Activate virtual environment
source ../venv/bin/activate

# Check if dependencies are installed
if ! python3 -c "import flask" 2>/dev/null; then
    echo "Dependencies not installed. Installing..."
    pip install -r ../requirements.txt
fi

# Run the Flask application
echo "Starting Flask server on http://127.0.0.1:5000"
python3 app.py
