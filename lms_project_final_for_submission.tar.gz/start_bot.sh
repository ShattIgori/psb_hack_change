#!/bin/bash

# Startup script for Telegram Bot

echo "=========================================="
echo "Starting Telegram Bot..."
echo "=========================================="

# Navigate to the bot directory
cd "$(dirname "$0")/telegram_bot"

# Check if virtual environment exists
if [ ! -d "../venv" ]; then
    echo "Virtual environment not found. Please run: python3 -m venv venv"
    exit 1
fi

# Activate virtual environment
source ../venv/bin/activate

# Check if .env file exists
if [ ! -f "../.env" ]; then
    echo "WARNING: .env file not found. Using default configuration."
    echo "Please create .env file from .env.example"
fi

# Check if dependencies are installed
if ! python3 -c "import telebot" 2>/dev/null; then
    echo "Dependencies not installed. Installing..."
    pip install -r ../requirements.txt
fi

# Run the bot
echo "Starting Telegram bot..."
python3 bot.py
