# Quick Start Guide / Быстрый старт

## English

### 1. Install Dependencies
```bash
cd lms_project
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env with your Telegram bot token and other settings
```

### 3. Start the LMS Platform
**Linux/macOS:**
```bash
./start_lms.sh
```

**Windows:**
```cmd
start_lms.bat
```

Or manually:
```bash
cd lms_platform
python3 app.py
```

The LMS will be available at: http://127.0.0.1:5000
- Demo login: `teacher@demo.ru` / `123`

### 4. Start the Telegram Bot (in a new terminal)
**Linux/macOS:**
```bash
./start_bot.sh
```

**Windows:**
```cmd
start_bot.bat
```

Or manually:
```bash
cd telegram_bot
python3 bot.py
```

### 5. Use the Bot
1. Find your bot in Telegram
2. Send `/start`
3. Enter your LMS email (e.g., `teacher@demo.ru`)
4. Start using the bot!

---

## Русский

### 1. Установите зависимости
```bash
cd lms_project
python3 -m venv venv
source venv/bin/activate  # На Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Настройте окружение
```bash
cp .env.example .env
# Отредактируйте .env, добавив токен вашего Telegram бота и другие настройки
```

### 3. Запустите LMS платформу
**Linux/macOS:**
```bash
./start_lms.sh
```

**Windows:**
```cmd
start_lms.bat
```

Или вручную:
```bash
cd lms_platform
python3 app.py
```

LMS будет доступна по адресу: http://127.0.0.1:5000
- Демо вход: `teacher@demo.ru` / `123`

### 4. Запустите Telegram бота (в новом терминале)
**Linux/macOS:**
```bash
./start_bot.sh
```

**Windows:**
```cmd
start_bot.bat
```

Или вручную:
```bash
cd telegram_bot
python3 bot.py
```

### 5. Используйте бота
1. Найдите вашего бота в Telegram
2. Отправьте `/start`
3. Введите ваш email из LMS (например, `teacher@demo.ru`)
4. Начните использовать бота!

---

## Troubleshooting / Решение проблем

### Bot can't connect to LMS / Бот не может подключиться к LMS
- Make sure the LMS platform is running / Убедитесь, что LMS платформа запущена
- Check the `LMS_API_BASE_URL` in `.env` / Проверьте `LMS_API_BASE_URL` в `.env`
- Verify the API key matches / Проверьте, что API ключ совпадает

### "Module not found" errors / Ошибки "Module not found"
- Make sure you activated the virtual environment / Убедитесь, что активировали виртуальное окружение
- Run `pip install -r requirements.txt` again / Запустите `pip install -r requirements.txt` снова

### Bot doesn't respond / Бот не отвечает
- Check your bot token in `.env` / Проверьте токен бота в `.env`
- Make sure the bot is running / Убедитесь, что бот запущен
- Check the console for error messages / Проверьте консоль на наличие ошибок
