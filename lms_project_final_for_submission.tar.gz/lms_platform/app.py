# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
import json
from sqlalchemy import text
from datetime import datetime, timedelta
import pytz


def get_current_time():
    return datetime.utcnow()


def get_utc_now():
    """Возвращает текущее время UTC без временной зоны"""
    return datetime.utcnow()


app = Flask(__name__)
app.config['SECRET_KEY'] = 'teacher-focused-lms-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///teacher_lms.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


# Модели базы данных
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='student')
    avatar = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    telegram_id = db.Column(db.BigInteger, unique=True, nullable=True)  # Для связки с ботом


class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    teacher_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    is_archived = db.Column(db.Boolean, default=False)
    archived_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)

    teacher = db.relationship('User', backref='courses_created')
    modules = db.relationship('Module', backref='course', lazy=True)
    assignments = db.relationship('Assignment', backref='course', lazy=True)
    groups = db.relationship('Group', backref='course', lazy=True)


class Module(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    order_index = db.Column(db.Integer, default=0)
    is_archived = db.Column(db.Boolean, default=False)
    archived_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    lessons = db.relationship('Lesson', backref='module', lazy=True)


class Lesson(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    module_id = db.Column(db.Integer, db.ForeignKey('module.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text)
    type = db.Column(db.String(50), default='text')
    file_url = db.Column(db.String(300))
    order_index = db.Column(db.Integer, default=0)
    is_archived = db.Column(db.Boolean, default=False)
    archived_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)


class Assignment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    max_score = db.Column(db.Float, nullable=False)
    due_date = db.Column(db.DateTime)
    allow_resubmission = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Group(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    students = db.relationship('GroupStudent', backref='group', lazy=True)


class GroupStudent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    group_id = db.Column(db.Integer, db.ForeignKey('group.id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)

    student = db.relationship('User', backref='group_memberships')


class AssignmentSubmission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    assignment_id = db.Column(db.Integer, db.ForeignKey('assignment.id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.Text)
    file_url = db.Column(db.String(300))
    status = db.Column(db.String(50), default='submitted')
    score = db.Column(db.Float)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    graded_at = db.Column(db.DateTime)

    # Relationships
    student = db.relationship('User', backref='submissions')
    assignment = db.relationship('Assignment', backref='submissions')
    comments = db.relationship('SubmissionComment', backref='submission', lazy=True, cascade='all, delete-orphan')


class SubmissionComment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    submission_id = db.Column(db.Integer, db.ForeignKey('assignment_submission.id'), nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    comment_text = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    author = db.relationship('User', backref='authored_comments')


class Test(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    time_limit = db.Column(db.Integer)
    max_attempts = db.Column(db.Integer, default=1)
    max_score = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    questions = db.relationship('TestQuestion', backref='test', lazy=True)


class TestQuestion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    test_id = db.Column(db.Integer, db.ForeignKey('test.id'), nullable=False)
    question_text = db.Column(db.Text, nullable=False)
    question_type = db.Column(db.String(50), default='multiple_choice')
    order_index = db.Column(db.Integer, default=0)
    max_score = db.Column(db.Float, default=1.0)

    options = db.relationship('TestOption', backref='question', lazy=True)


class TestOption(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question_id = db.Column(db.Integer, db.ForeignKey('test_question.id'), nullable=False)
    option_text = db.Column(db.Text, nullable=False)
    is_correct = db.Column(db.Boolean, default=False)
    order_index = db.Column(db.Integer, default=0)


class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(50), default='info')  # info, success, warning, danger
    is_read = db.Column(db.Boolean, default=False)
    related_entity_type = db.Column(db.String(50))  # course, assignment, submission, etc.
    related_entity_id = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    user = db.relationship('User', backref='notifications')


class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'))
    type = db.Column(db.String(50), nullable=False)  # ASSIGNMENT_CREATED, ASSIGNMENT_SUBMITTED, etc.
    payload = db.Column(db.Text)  # JSON: score, assignment_id, etc.
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', backref='events')


class Recommendation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'))
    type = db.Column(db.String(50), nullable=False)  # NEXT_LESSON, RETAKE_TEST, TEACHER_ACTION, etc.
    message = db.Column(db.Text, nullable=False)  # Готовый текст для UI/бота
    action_link = db.Column(db.String(500))  # URL в web, deep link для бота
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime)
    status = db.Column(db.String(50), default='NEW')  # NEW, SHOWN_WEB, SENT_TELEGRAM, DONE, IGNORED
    telegram_sent = db.Column(db.Boolean, default=False)  # Флаг, отправлено ли уведомление в Telegram

    user = db.relationship('User', backref='recommendations')


class ChangeHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    entity_type = db.Column(db.String(50), nullable=False)
    entity_id = db.Column(db.Integer, nullable=False)
    action = db.Column(db.String(50), nullable=False)
    changes = db.Column(db.Text)
    changed_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    changed_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', backref='changes_made')


# Вспомогательные функции для архивирования и истории
def archive_course(course_id, user_id):
    """Архивирует курс и все его содержимое"""
    course = Course.query.get_or_404(course_id)
    course.is_archived = True
    course.archived_at = datetime.utcnow()

    # Архивируем все модули курса
    for module in course.modules:
        archive_module(module.id, user_id)

    # Создаем уведомление для преподавателя
    create_notification(
        user_id=user_id,
        title='Курс архивирован',
        message=f'Курс "{course.title}" успешно архивирован',
        type='info',
        related_entity_type='course',
        related_entity_id=course_id
    )

    # Записываем в историю
    log_change('course', course_id, 'archive', f'Курс "{course.title}" архивирован', user_id)

    db.session.commit()
    return True


def archive_module(module_id, user_id):
    """Архивирует модуль и все его уроки"""
    module = Module.query.get_or_404(module_id)
    module.is_archived = True
    module.archived_at = datetime.utcnow()

    # Архивируем все уроки модуля
    for lesson in module.lessons:
        archive_lesson(lesson.id, user_id)

    # Записываем в историю
    log_change('module', module_id, 'archive', f'Модуль "{module.title}" архивирован', user_id)

    db.session.commit()
    return True


def archive_lesson(lesson_id, user_id):
    """Архивирует урок"""
    lesson = Lesson.query.get_or_404(lesson_id)
    lesson.is_archived = True
    lesson.archived_at = datetime.utcnow()

    # Записываем в историю
    log_change('lesson', lesson_id, 'archive', f'Урок "{lesson.title}" архивирован', user_id)

    db.session.commit()
    return True


def restore_course(course_id, user_id):
    """Восстанавливает курс из архива"""
    course = Course.query.get_or_404(course_id)
    course.is_archived = False
    course.archived_at = None

    # Создаем уведомление для преподавателя
    create_notification(
        user_id=user_id,
        title='Курс восстановлен',
        message=f'Курс "{course.title}" восстановлен из архива',
        type='success',
        related_entity_type='course',
        related_entity_id=course_id
    )

    log_change('course', course_id, 'restore', f'Курс "{course.title}" восстановлен', user_id)
    db.session.commit()
    return True


def restore_module(module_id, user_id):
    """Восстанавливает модуль из архива"""
    module = Module.query.get_or_404(module_id)
    module.is_archived = False
    module.archived_at = None

    log_change('module', module_id, 'restore', f'Модуль "{module.title}" восстановлен', user_id)
    db.session.commit()
    return True


def restore_lesson(lesson_id, user_id):
    """Восстанавливает урок из архива"""
    lesson = Lesson.query.get_or_404(lesson_id)
    lesson.is_archived = False
    lesson.archived_at = None

    log_change('lesson', lesson_id, 'restore', f'Урок "{lesson.title}" восстановлен', user_id)
    db.session.commit()
    return True


def log_change(entity_type, entity_id, action, changes, user_id):
    """Записывает изменение в историю"""
    change = ChangeHistory(
        entity_type=entity_type,
        entity_id=entity_id,
        action=action,
        changes=changes,
        changed_by=user_id
    )
    db.session.add(change)
    db.session.commit()


def get_change_history(entity_type=None, entity_id=None, limit=50):
    """Получает историю изменений"""
    query = ChangeHistory.query.order_by(ChangeHistory.changed_at.desc())

    if entity_type:
        query = query.filter(ChangeHistory.entity_type == entity_type)
    if entity_id:
        query = query.filter(ChangeHistory.entity_id == entity_id)

    return query.limit(limit).all()


def get_teacher_courses(teacher_id, include_archived=False):
    """Получает курсы преподавателя"""
    query = Course.query.filter_by(teacher_id=teacher_id)
    if not include_archived:
        query = query.filter_by(is_archived=False)
    return query.all()


def get_course_modules(course_id, include_archived=False):
    """Получает модули курса"""
    query = Module.query.filter_by(course_id=course_id)
    if not include_archived:
        query = query.filter_by(is_archived=False)
    return query.order_by(Module.order_index).all()


def get_module_lessons(module_id, include_archived=False):
    """Получает уроки модуля"""
    query = Lesson.query.filter_by(module_id=module_id)
    if not include_archived:
        query = query.filter_by(is_archived=False)
    return query.order_by(Lesson.order_index).all()


def get_course_stats(course_id):
    """Получает статистику курса"""
    students_count = db.session.query(GroupStudent).join(Group).filter(Group.course_id == course_id).count()
    assignments_count = Assignment.query.filter_by(course_id=course_id).count()
    submissions_count = AssignmentSubmission.query.join(Assignment).filter(Assignment.course_id == course_id).count()

    # Расчет среднего балла
    graded_submissions = AssignmentSubmission.query.join(Assignment).filter(
        Assignment.course_id == course_id,
        AssignmentSubmission.score.isnot(None)
    ).all()

    average_score = 0
    if graded_submissions:
        total_score = sum(sub.score for sub in graded_submissions if sub.score is not None)
        average_score = total_score / len(graded_submissions)

    return {
        'students_count': students_count,
        'average_score': round(average_score, 2),
        'assignments_count': assignments_count,
        'submissions_count': submissions_count
    }


def get_course_structure(course_id):
    """Возвращает полную структуру курса с модулями и уроками"""
    course = Course.query.get(course_id)
    if not course:
        return None

    modules = get_course_modules(course_id)

    course_structure = {
        'course': course,
        'modules': []
    }

    for module in modules:
        lessons = get_module_lessons(module.id)
        course_structure['modules'].append({
            'module': module,
            'lessons': lessons
        })

    return course_structure


def update_database_schema():
    """Создает или обновляет структуру базы данных"""
    with app.app_context():
        # Просто создаем все таблицы
        db.create_all()
        print("✅ Таблицы базы данных созданы/обновлены")

        # Проверяем существование основных таблиц
        inspector = db.inspect(db.engine)
        tables = inspector.get_table_names()
        print(f"✅ Создано таблиц: {len(tables)}")
        for table in tables:
            print(f"   - {table}")
        # Для таблицы User
        try:
            user_columns = [col['name'] for col in inspector.get_columns('user')]
            if 'is_active' not in user_columns:
                db.session.execute(text('ALTER TABLE user ADD COLUMN is_active BOOLEAN DEFAULT TRUE'))
                db.session.commit()
                print("Добавлен столбец is_active в таблицу user")
        except Exception as e:
            print(f"Ошибка при проверке таблицы user: {e}")

        # Для таблицы Course
        try:
            course_columns = [col['name'] for col in inspector.get_columns('course')]
            if 'is_archived' not in course_columns:
                db.session.execute(text('ALTER TABLE course ADD COLUMN is_archived BOOLEAN DEFAULT FALSE'))
                db.session.commit()
                print("Добавлен столбец is_archived в таблицу course")
            if 'archived_at' not in course_columns:
                db.session.execute(text('ALTER TABLE course ADD COLUMN archived_at DATETIME'))
                db.session.commit()
                print("Добавлен столбец archived_at в таблицу course")
        except Exception as e:
            print(f"Ошибка при проверке таблица course: {e}")

        # Для таблицы Module
        try:
            module_columns = [col['name'] for col in inspector.get_columns('module')]
            if 'is_archived' not in module_columns:
                db.session.execute(text('ALTER TABLE module ADD COLUMN is_archived BOOLEAN DEFAULT FALSE'))
                db.session.commit()
                print("Добавлен столбец is_archived в таблицу module")
            if 'archived_at' not in module_columns:
                db.session.execute(text('ALTER TABLE module ADD COLUMN archived_at DATETIME'))
                db.session.commit()
                print("Добавлен столбец archived_at в таблицу module")
        except Exception as e:
            print(f"Ошибка при проверке таблицы module: {e}")

        # Для таблицы Lesson
        try:
            lesson_columns = [col['name'] for col in inspector.get_columns('lesson')]
            if 'is_archived' not in lesson_columns:
                db.session.execute(text('ALTER TABLE lesson ADD COLUMN is_archived BOOLEAN DEFAULT FALSE'))
                db.session.commit()
                print("Добавлен столбец is_archived в таблицу lesson")
            if 'archived_at' not in lesson_columns:
                db.session.execute(text('ALTER TABLE lesson ADD COLUMN archived_at DATETIME'))
                db.session.commit()
                print("Добавлен столбец archived_at в таблицу lesson")
        except Exception as e:
            print(f"Ошибка при проверке таблицы lesson: {e}")

        print("Проверка структуры базы данных завершена")


# Инициализация базы данных
def init_database():
    with app.app_context():
        # Сначала обновляем схему базы данных
        update_database_schema()

        # Создаем тестового преподавателя если его нет
        if not User.query.filter_by(role='teacher').first():
            teacher = User(
                email='teacher@demo.ru',
                password_hash=generate_password_hash('123'),
                full_name='Профессор Иванов',
                role='teacher'
            )
            db.session.add(teacher)
            db.session.commit()

            # Создаем тестовый курс
            course = Course(
                title='Программирование на Python',
                description='Полный курс программирования на языке Python для начинающих',
                teacher_id=teacher.id
            )
            db.session.add(course)
            db.session.commit()

            # Записываем создание в историю
            log_change('course', course.id, 'create', f'Курс "{course.title}" создан', teacher.id)

            # Создаем модуль
            module = Module(
                course_id=course.id,
                title='Введение в Python',
                description='Базовые концепции языка Python',
                order_index=1
            )
            db.session.add(module)
            db.session.commit()
            log_change('module', module.id, 'create', f'Модуль "{module.title}" создан', teacher.id)

            # Создаем уроки
            lessons = [
                {'title': 'Установка Python', 'type': 'text', 'order': 1},
                {'title': 'Переменные и типы данных', 'type': 'text', 'order': 2},
                {'title': 'Условные операторы', 'type': 'text', 'order': 3},
            ]

            for lesson_data in lessons:
                lesson = Lesson(
                    module_id=module.id,
                    title=lesson_data['title'],
                    type=lesson_data['type'],
                    order_index=lesson_data['order'],
                    content=f"Содержание урока: {lesson_data['title']}"
                )
                db.session.add(lesson)
                db.session.commit()
                log_change('lesson', lesson.id, 'create', f'Урок "{lesson.title}" создан', teacher.id)

            # Создаем задание
            assignment = Assignment(
                course_id=course.id,
                title='Первая программа на Python',
                description='Напишите программу "Hello World" и опишите процесс её создания',
                max_score=10.0,
                due_date=datetime.utcnow() + timedelta(days=7)
            )
            db.session.add(assignment)

            # Создаем группу
            group = Group(
                course_id=course.id,
                name='Группа 1'
            )
            db.session.add(group)

            db.session.commit()
            print("Тестовые данные созданы!")


# Вспомогательные функции для уведомлений
def create_notification(user_id, title, message, type='info', related_entity_type=None, related_entity_id=None):
    """Создает новое уведомление"""
    notification = Notification(
        user_id=user_id,
        title=title,
        message=message,
        type=type,
        related_entity_type=related_entity_type,
        related_entity_id=related_entity_id
    )
    db.session.add(notification)
    db.session.commit()
    return notification


def get_user_notifications(user_id, limit=10, unread_only=False):
    """Получает уведомления пользователя"""
    query = Notification.query.filter_by(user_id=user_id)
    if unread_only:
        query = query.filter_by(is_read=False)
    return query.order_by(Notification.created_at.desc()).limit(limit).all()


def get_unread_notifications_count(user_id):
    """Получает количество непрочитанных уведомлений"""
    return Notification.query.filter_by(user_id=user_id, is_read=False).count()


def mark_notification_as_read(notification_id, user_id):
    """Помечает уведомление как прочитанное"""
    notification = Notification.query.filter_by(id=notification_id, user_id=user_id).first()
    if notification:
        notification.is_read = True
        db.session.commit()
        return True
    return False


def mark_all_notifications_as_read(user_id):
    """Помечает все уведомления пользователя как прочитанные"""
    Notification.query.filter_by(user_id=user_id, is_read=False).update({'is_read': True})
    db.session.commit()


def create_system_notifications():
    """Создает системные уведомления для различных событий"""
    pass


# Маршруты аутентификации
@app.route('/')
def index():
    if 'user' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        full_name = request.form['full_name']
        role = request.form.get('role', 'student')

        if User.query.filter_by(email=email).first():
            flash('Пользователь с таким email уже существует', 'error')
        else:
            user = User(
                email=email,
                password_hash=generate_password_hash(password),
                full_name=full_name,
                role=role
            )
            db.session.add(user)
            db.session.commit()
            flash('Регистрация успешна! Теперь войдите в систему.', 'success')
            return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password_hash, password):
            session['user'] = {
                'id': user.id,
                'email': user.email,
                'name': user.full_name,
                'role': user.role,
                'avatar': user.avatar
            }
            flash('Вход выполнен успешно!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Неверный email или пароль', 'error')

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('index'))


@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))

    user = session['user']

    if user['role'] == 'teacher':
        # Получаем курсы преподавателя
        courses = get_teacher_courses(user['id'])
        courses_with_stats = []
        upcoming_assignments = []

        current_time = datetime.utcnow()

        for course in courses:
            stats = get_course_stats(course.id)
            courses_with_stats.append({
                'course': course,
                'stats': stats
            })

            # Получаем задания с будущими дедлайнами
            for assignment in course.assignments:
                if assignment.due_date and assignment.due_date > current_time:
                    upcoming_assignments.append(assignment)

        # Сортируем по дате и берем первые 3
        upcoming_assignments.sort(key=lambda x: x.due_date)
        upcoming_assignments = upcoming_assignments[:3]

        # Задания на проверку
        course_ids = [course.id for course in courses]
        pending_submissions_count = AssignmentSubmission.query.filter(
            AssignmentSubmission.assignment_id.in_(
                db.session.query(Assignment.id).filter(Assignment.course_id.in_(course_ids))
            ),
            AssignmentSubmission.status == 'submitted'
        ).count()

        return render_template('teacher/dashboard.html',
                               user=user,
                               courses=courses_with_stats,
                               pending_submissions=pending_submissions_count,
                               upcoming_assignments=upcoming_assignments)
    else:
        return render_template('student/coming_soon.html', user=user)


@app.route('/teacher/courses')
def teacher_courses():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    user = session['user']
    courses = get_teacher_courses(user['id'])

    courses_with_stats = []
    for course in courses:
        stats = get_course_stats(course.id)
        courses_with_stats.append({
            'course': course,
            'stats': stats
        })

    return render_template('teacher/courses.html', user=user, courses=courses_with_stats)


@app.route('/teacher/course/create', methods=['GET', 'POST'])
def teacher_create_course():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        title = request.form['title']
        description = request.form.get('description', '')

        course = Course(
            title=title,
            description=description,
            teacher_id=session['user']['id']
        )
        db.session.add(course)
        db.session.commit()

        # Записываем в историю
        log_change('course', course.id, 'create', f'Курс "{course.title}" создан', session['user']['id'])

        # СОЗДАЕМ УВЕДОМЛЕНИЕ О СОЗДАНИИ КУРСА
        create_notification(
            user_id=session['user']['id'],
            title='Курс создан',
            message=f'Курс "{course.title}" успешно создан',
            type='success',
            related_entity_type='course',
            related_entity_id=course.id
        )

        flash('Курс успешно создан!', 'success')
        return redirect(url_for('teacher_course_detail', course_id=course.id))

    return render_template('teacher/course_create.html', user=session['user'])


@app.route('/teacher/course/<int:course_id>')
def teacher_course_detail(course_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    course = Course.query.get_or_404(course_id)
    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_courses'))

    modules = get_course_modules(course_id)
    assignments = Assignment.query.filter_by(course_id=course_id).all()
    groups = Group.query.filter_by(course_id=course_id).all()
    stats = get_course_stats(course_id)

    return render_template('teacher/course_detail.html',
                           user=session['user'],
                           course=course,
                           modules=modules,
                           assignments=assignments,
                           groups=groups,
                           stats=stats)


@app.route('/teacher/course/<int:course_id>/edit', methods=['GET', 'POST'])
def teacher_edit_course(course_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    course = Course.query.get_or_404(course_id)
    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_courses'))

    if request.method == 'POST':
        old_title = course.title
        course.title = request.form['title']
        course.description = request.form.get('description', '')
        course.is_active = 'is_active' in request.form
        course.updated_at = datetime.utcnow()

        db.session.commit()

        # Записываем изменения в историю
        changes = []
        if old_title != course.title:
            changes.append(f'Название изменено: "{old_title}" -> "{course.title}"')
        if course.is_active:
            changes.append('Курс активирован')
        else:
            changes.append('Курс деактивирован')

        if changes:
            log_change('course', course.id, 'update', '; '.join(changes), session['user']['id'])

        # СОЗДАЕМ УВЕДОМЛЕНИЕ ОБ ИЗМЕНЕНИИ КУРСА
        create_notification(
            user_id=session['user']['id'],
            title='Курс изменен',
            message=f'Курс "{course.title}" успешно обновлен',
            type='info',
            related_entity_type='course',
            related_entity_id=course.id
        )

        flash('Курс успешно обновлен!', 'success')
        return redirect(url_for('teacher_course_detail', course_id=course.id))

    return render_template('teacher/course_edit.html', user=session['user'], course=course)


@app.route('/teacher/course/<int:course_id>/archive', methods=['POST'])
def teacher_archive_course(course_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    course = Course.query.get_or_404(course_id)
    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        archive_course(course_id, session['user']['id'])
        flash('Курс успешно архивирован', 'success')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/teacher/course/<int:course_id>/materials')
def teacher_course_materials(course_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    course = Course.query.get_or_404(course_id)
    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_courses'))

    modules = get_course_modules(course_id)
    for module in modules:
        module.lessons_list = get_module_lessons(module.id)

    return render_template('teacher/course_materials.html',
                           user=session['user'],
                           course=course,
                           modules=modules)


# Управление модулями
@app.route('/teacher/course/<int:course_id>/module/create', methods=['GET', 'POST'])
def teacher_create_module(course_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    course = Course.query.get_or_404(course_id)
    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_courses'))

    if request.method == 'POST':
        title = request.form['title']
        description = request.form.get('description', '')
        order_index = request.form.get('order_index', 0)

        module = Module(
            course_id=course_id,
            title=title,
            description=description,
            order_index=order_index
        )
        db.session.add(module)
        db.session.commit()

        # Записываем в историю
        log_change('module', module.id, 'create', f'Модуль "{module.title}" создан', session['user']['id'])

        # СОЗДАЕМ УВЕДОМЛЕНИЕ О СОЗДАНИИ МОДУЛЯ
        create_notification(
            user_id=session['user']['id'],
            title='Модуль создан',
            message=f'Модуль "{module.title}" успешно создан в курсе "{course.title}"',
            type='success',
            related_entity_type='module',
            related_entity_id=module.id
        )

        flash('Модуль успешно создан!', 'success')
        return redirect(url_for('teacher_course_materials', course_id=course_id))

    return render_template('teacher/module_create.html', user=session['user'], course=course)


@app.route('/teacher/module/<int:module_id>/edit', methods=['GET', 'POST'])
def teacher_edit_module(route_module_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    module = Module.query.get_or_404(route_module_id)
    course = Course.query.get_or_404(module.course_id)

    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_courses'))

    if request.method == 'POST':
        old_title = module.title
        module.title = request.form['title']
        module.description = request.form.get('description', '')
        module.order_index = request.form.get('order_index', 0)

        db.session.commit()

        # Записываем изменения в историю
        if old_title != module.title:
            log_change('module', module.id, 'update', f'Название изменено: "{old_title}" -> "{module.title}"',
                       session['user']['id'])

        # СОЗДАЕМ УВЕДОМЛЕНИЕ ОБ ИЗМЕНЕНИИ МОДУЛЯ
        create_notification(
            user_id=session['user']['id'],
            title='Модуль изменен',
            message=f'Модуль "{module.title}" в курсе "{course.title}" успешно обновлен',
            type='info',
            related_entity_type='module',
            related_entity_id=module.id
        )

        flash('Модуль успешно обновлен!', 'success')
        return redirect(url_for('teacher_course_materials', course_id=course.id))

    return render_template('teacher/module_edit.html', user=session['user'], module=module, course=course)


@app.route('/teacher/module/<int:module_id>/archive', methods=['POST'])
def teacher_archive_module(route_module_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    module = Module.query.get_or_404(route_module_id)
    course = Course.query.get_or_404(module.course_id)

    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        archive_module(route_module_id, session['user']['id'])

        # СОЗДАЕМ УВЕДОМЛЕНИЕ ОБ АРХИВАЦИИ МОДУЛЯ
        create_notification(
            user_id=session['user']['id'],
            title='Модуль архивирован',
            message=f'Модуль "{module.title}" в курсе "{course.title}" перемещен в архив',
            type='warning',
            related_entity_type='module',
            related_entity_id=route_module_id
        )

        flash('Модуль успешно архивирован', 'success')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Управление уроками
@app.route('/teacher/module/<int:module_id>/lesson/create', methods=['GET', 'POST'])
def teacher_create_lesson(module_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    module = Module.query.get_or_404(module_id)
    course = Course.query.get_or_404(module.course_id)

    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_courses'))

    if request.method == 'POST':
        title = request.form['title']
        content = request.form.get('content', '')
        lesson_type = request.form.get('type', 'text')
        order_index = request.form.get('order_index', 0)

        lesson = Lesson(
            module_id=module_id,
            title=title,
            content=content,
            type=lesson_type,
            order_index=order_index
        )
        db.session.add(lesson)
        db.session.commit()

        # Записываем в историю
        log_change('lesson', lesson.id, 'create', f'Урок "{lesson.title}" создан', session['user']['id'])

        # СОЗДАЕМ УВЕДОМЛЕНИЕ О СОЗДАНИИ УРОКА
        create_notification(
            user_id=session['user']['id'],
            title='Урок создан',
            message=f'Урок "{lesson.title}" успешно создан в модуле "{module.title}"',
            type='success',
            related_entity_type='lesson',
            related_entity_id=lesson.id
        )

        flash('Урок успешно создан!', 'success')
        return redirect(url_for('teacher_course_materials', course_id=course.id))

    return render_template('teacher/lesson_create.html', user=session['user'], module=module, course=course)


@app.route('/teacher/lesson/<int:lesson_id>/edit', methods=['GET', 'POST'])
def teacher_edit_lesson(route_lesson_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    lesson = Lesson.query.get_or_404(route_lesson_id)
    module = Module.query.get_or_404(lesson.module_id)
    course = Course.query.get_or_404(module.course_id)

    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_courses'))

    if request.method == 'POST':
        old_title = lesson.title
        lesson.title = request.form['title']
        lesson.content = request.form.get('content', '')
        lesson.type = request.form.get('type', 'text')
        lesson.order_index = request.form.get('order_index', 0)
        lesson.updated_at = datetime.utcnow()

        db.session.commit()

        # Записываем изменения в историю
        if old_title != lesson.title:
            log_change('lesson', lesson.id, 'update', f'Название изменено: "{old_title}" -> "{lesson.title}"',
                       session['user']['id'])

        # СОЗДАЕМ УВЕДОМЛЕНИЕ ОБ ИЗМЕНЕНИИ УРОКА
        create_notification(
            user_id=session['user']['id'],
            title='Урок изменен',
            message=f'Урок "{lesson.title}" в модуле "{module.title}" успешно обновлен',
            type='info',
            related_entity_type='lesson',
            related_entity_id=lesson.id
        )

        flash('Урок успешно обновлен!', 'success')
        return redirect(url_for('teacher_course_materials', course_id=course.id))

    return render_template('teacher/lesson_edit.html', user=session['user'], lesson=lesson, module=module,
                           course=course)


@app.route('/teacher/lesson/<int:lesson_id>/archive', methods=['POST'])
def teacher_archive_lesson(route_lesson_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    lesson = Lesson.query.get_or_404(route_lesson_id)
    module = Module.query.get_or_404(lesson.module_id)
    course = Course.query.get_or_404(module.course_id)

    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        archive_lesson(route_lesson_id, session['user']['id'])

        # СОЗДАЕМ УВЕДОМЛЕНИЕ ОБ АРХИВАЦИИ УРОКА
        create_notification(
            user_id=session['user']['id'],
            title='Урок архивирован',
            message=f'Урок "{lesson.title}" в модуле "{module.title}" перемещен в архив',
            type='warning',
            related_entity_type='lesson',
            related_entity_id=route_lesson_id
        )

        flash('Урок успешно архивирован', 'success')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Маршруты восстановления из отдельных страниц
@app.route('/teacher/course/<int:course_id>/restore', methods=['POST'])
def teacher_restore_course(course_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    course = Course.query.get_or_404(course_id)
    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        restore_course(course_id, session['user']['id'])
        flash('Курс успешно восстановлен', 'success')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/teacher/module/<int:module_id>/restore', methods=['POST'])
def teacher_restore_module(route_module_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    module = Module.query.get_or_404(route_module_id)
    course = Course.query.get_or_404(module.course_id)

    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        restore_module(route_module_id, session['user']['id'])

        # СОЗДАЕМ УВЕДОМЛЕНИЕ О ВОССТАНОВЛЕНИИ МОДУЛЯ
        create_notification(
            user_id=session['user']['id'],
            title='Модуль восстановлен',
            message=f'Модуль "{module.title}" восстановлен из архива в курсе "{course.title}"',
            type='success',
            related_entity_type='module',
            related_entity_id=route_module_id
        )

        flash('Модуль успешно восстановлен', 'success')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/teacher/lesson/<int:lesson_id>/restore', methods=['POST'])
def teacher_restore_lesson(route_lesson_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    lesson = Lesson.query.get_or_404(route_lesson_id)
    module = Module.query.get_or_404(lesson.module_id)
    course = Course.query.get_or_404(module.course_id)

    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        restore_lesson(route_lesson_id, session['user']['id'])

        # СОЗДАЕМ УВЕДОМЛЕНИЕ О ВОССТАНОВЛЕНИИ УРОКА
        create_notification(
            user_id=session['user']['id'],
            title='Урок восстановлен',
            message=f'Урок "{lesson.title}" восстановлен из архива в модуле "{module.title}"',
            type='success',
            related_entity_type='lesson',
            related_entity_id=route_lesson_id
        )

        flash('Урок успешно восстановлен', 'success')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Маршруты для архива и восстановления
@app.route('/teacher/archive')
def teacher_archive():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    user = session['user']

    # Получаем архивированные курсы, модули и уроки
    archived_courses = Course.query.filter_by(teacher_id=user['id'], is_archived=True).all()
    archived_modules = Module.query.join(Course).filter(
        Course.teacher_id == user['id'],
        Module.is_archived == True
    ).all()
    archived_lessons = Lesson.query.join(Module).join(Course).filter(
        Course.teacher_id == user['id'],
        Lesson.is_archived == True
    ).all()

    return render_template('teacher/archive.html',
                           user=user,
                           archived_courses=archived_courses,
                           archived_modules=archived_modules,
                           archived_lessons=archived_lessons)


@app.route('/teacher/archive/course/<int:course_id>/restore', methods=['POST'])
def teacher_restore_course_archive(course_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    course = Course.query.get_or_404(course_id)
    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        restore_course(course_id, session['user']['id'])
        flash('Курс успешно восстановлен из архива', 'success')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/teacher/archive/module/<int:module_id>/restore', methods=['POST'])
def teacher_restore_module_archive(route_module_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    module = Module.query.get_or_404(route_module_id)
    course = Course.query.get_or_404(module.course_id)

    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        restore_module(route_module_id, session['user']['id'])
        flash('Модуль успешно восстановлен из архива', 'success')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/teacher/archive/lesson/<int:lesson_id>/restore', methods=['POST'])
def teacher_restore_lesson_archive(route_lesson_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    lesson = Lesson.query.get_or_404(route_lesson_id)
    module = Module.query.get_or_404(lesson.module_id)
    course = Course.query.get_or_404(module.course_id)

    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        restore_lesson(route_lesson_id, session['user']['id'])
        flash('Урок успешно восстановлен из архива', 'success')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/teacher/archive/course/<int:course_id>/details')
def teacher_archive_course_details(course_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    course = Course.query.get_or_404(course_id)
    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_archive'))

    # Получаем архивированные модули и уроки этого курса
    archived_modules = Module.query.filter_by(course_id=course_id, is_archived=True).all()
    archived_lessons = Lesson.query.join(Module).filter(
        Module.course_id == course_id,
        Lesson.is_archived == True
    ).all()

    return render_template('teacher/archive_course_details.html',
                           user=session['user'],
                           course=course,
                           archived_modules=archived_modules,
                           archived_lessons=archived_lessons)


# Маршруты для просмотра истории
@app.route('/teacher/history')
def teacher_history():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    user = session['user']
    history = get_change_history(limit=100)

    return render_template('teacher/history.html',
                           user=user,
                           history=history)


# Другие маршруты преподавателя
@app.route('/teacher/assignments')
def teacher_assignments():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    user = session['user']
    courses = get_teacher_courses(user['id'])
    course_ids = [course.id for course in courses]

    # Получаем задания только тех курсов, которые принадлежат преподавателю
    assignments = Assignment.query.filter(Assignment.course_id.in_(course_ids)).order_by(
        Assignment.created_at.desc()).all()

    return render_template('teacher/assignments_teacher.html',
                           user=user,
                           assignments=assignments,
                           courses=courses)


# Обновляем маршрут teacher_tests
@app.route('/teacher/tests')
def teacher_tests():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    user = session['user']
    courses = get_teacher_courses(user['id'])
    course_ids = [course.id for course in courses]
    tests = Test.query.filter(Test.course_id.in_(course_ids)).all()

    return render_template('teacher/tests.html',
                           user=user,
                           tests=tests,
                           courses=courses)


# Обновляем маршрут teacher_grading
@app.route('/teacher/grading')
def teacher_grading():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    user = session['user']
    courses = get_teacher_courses(user['id'])
    course_ids = [course.id for course in courses]

    # Получаем работы на проверку
    pending_submissions = AssignmentSubmission.query.filter(
        AssignmentSubmission.assignment_id.in_(
            db.session.query(Assignment.id).filter(Assignment.course_id.in_(course_ids))
        ),
        AssignmentSubmission.status == 'submitted'
    ).all()

    return render_template('teacher/grading.html',
                           user=user,
                           pending_submissions=pending_submissions)


# Обновляем маршрут teacher_groups
@app.route('/teacher/groups')
def teacher_groups():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    user = session['user']
    courses = get_teacher_courses(user['id'])

    return render_template('teacher/groups.html',
                           user=user,
                           courses=courses)


# Обновляем маршрут teacher_grades
@app.route('/teacher/grades')
def teacher_grades():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    user = session['user']
    courses = get_teacher_courses(user['id'])

    return render_template('teacher/grades.html',
                           user=user,
                           courses=courses)


@app.route('/profile')
def profile():
    if 'user' not in session:
        return redirect(url_for('login'))

    return render_template('profile.html', user=session['user'])


# API endpoints для преподавателя
@app.route('/api/teacher/create_course', methods=['POST'])
def api_create_course():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json()
    course = Course(
        title=data['title'],
        description=data.get('description', ''),
        teacher_id=session['user']['id']
    )
    db.session.add(course)
    db.session.commit()

    log_change('course', course.id, 'create', f'Курс "{course.title}" создан', session['user']['id'])

    return jsonify({'success': True, 'course_id': course.id})


@app.route('/api/teacher/update_order', methods=['POST'])
def api_update_order():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json()
    item_type = data.get('type')
    items = data.get('items', [])

    try:
        for item in items:
            if item_type == 'module':
                module = Module.query.get(item['id'])
                if module:
                    course = Course.query.get(module.course_id)
                    if course.teacher_id == session['user']['id']:
                        module.order_index = item['order']
            elif item_type == 'lesson':
                lesson = Lesson.query.get(item['id'])
                if lesson:
                    module = Module.query.get(lesson.module_id)
                    course = Course.query.get(module.course_id)
                    if course.teacher_id == session['user']['id']:
                        lesson.order_index = item['order']

        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/teacher/course/<int:course_id>/clone', methods=['POST'])
def teacher_clone_course(course_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    original_course = Course.query.get_or_404(course_id)
    if original_course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        # Создаем новый курс
        new_course = Course(
            title=f"{original_course.title} (Копия)",
            description=original_course.description,
            teacher_id=session['user']['id']
        )
        db.session.add(new_course)
        db.session.flush()

        log_change('course', new_course.id, 'create', f'Курс "{new_course.title}" создан как копия',
                   session['user']['id'])

        # Копируем модули
        modules = get_course_modules(course_id, include_archived=True)
        module_mapping = {}

        for module in modules:
            if not module.is_archived:  # Копируем только неархивированные модули
                new_module = Module(
                    course_id=new_course.id,
                    title=module.title,
                    description=module.description,
                    order_index=module.order_index
                )
                db.session.add(new_module)
                db.session.flush()
                module_mapping[module.id] = new_module.id

                log_change('module', new_module.id, 'create', f'Модуль "{new_module.title}" создан',
                           session['user']['id'])

                # Копируем уроки
                lessons = get_module_lessons(module.id, include_archived=True)
                for lesson in lessons:
                    if not lesson.is_archived:  # Копируем только неархивированные уроки
                        new_lesson = Lesson(
                            module_id=new_module.id,
                            title=lesson.title,
                            content=lesson.content,
                            type=lesson.type,
                            order_index=lesson.order_index
                        )
                        db.session.add(new_lesson)
                        db.session.flush()
                        log_change('lesson', new_lesson.id, 'create', f'Урок "{new_lesson.title}" создан',
                                   session['user']['id'])

        db.session.commit()
        flash('Курс успешно скопирован!', 'success')
        return jsonify({'success': True, 'new_course_id': new_course.id})

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@app.route('/teacher/submission/<int:submission_id>')
def teacher_submission_detail(submission_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    submission = db.session.get(AssignmentSubmission, submission_id)
    if not submission:
        flash('Работа не найдена', 'error')
        return redirect(url_for('teacher_grading'))

    assignment = db.session.get(Assignment, submission.assignment_id)
    if not assignment:
        flash('Задание не найдено', 'error')
        return redirect(url_for('teacher_grading'))

    course = db.session.get(Course, assignment.course_id)
    if not course:
        flash('Курс не найден', 'error')
        return redirect(url_for('teacher_grading'))

    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_grading'))

    student = db.session.get(User, submission.student_id)

    # Получаем комментарии
    comments = SubmissionComment.query.filter_by(
        submission_id=submission_id
    ).order_by(SubmissionComment.created_at).all()

    return render_template('teacher/submission_detail.html',
                           user=session['user'],
                           submission=submission,
                           assignment=assignment,
                           course=course,
                           student=student,
                           comments=comments)


@app.route('/teacher/submission/<int:submission_id>/grade', methods=['POST'])
def teacher_grade_submission(submission_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    submission = db.session.get(AssignmentSubmission, submission_id)
    if not submission:
        return jsonify({'error': 'Работа не найдена'}), 404

    assignment = db.session.get(Assignment, submission.assignment_id)
    if not assignment:
        return jsonify({'error': 'Задание не найдено'}), 404

    course = db.session.get(Course, assignment.course_id)
    if not course:
        return jsonify({'error': 'Курс не найден'}), 404

    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        data = request.get_json()
        score = float(data['score'])
        comment_text = data.get('comment', '')

        if score < 0 or score > assignment.max_score:
            return jsonify({'error': f'Оценка должна быть от 0 до {assignment.max_score}'}), 400

        submission.score = score
        submission.status = 'graded'
        submission.graded_at = datetime.utcnow()

        if comment_text:
            comment = SubmissionComment(
                submission_id=submission_id,
                author_id=session['user']['id'],
                comment_text=comment_text
            )
            db.session.add(comment)

        db.session.commit()

        # Создаем уведомление для студента
        create_notification(
            user_id=submission.student_id,
            title='Работа проверена',
            message=f'Ваша работа "{assignment.title}" проверена. Оценка: {score}/{assignment.max_score}',
            type='success',
            related_entity_type='submission',
            related_entity_id=submission_id
        )

        log_change('submission', submission_id, 'grade',
                   f'Работа оценена: {score}/{assignment.max_score}', session['user']['id'])

        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


# Маршруты для управления тестами
@app.route('/teacher/test/create', methods=['GET', 'POST'])
def teacher_create_test():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        data = request.get_json()
        test = Test(
            course_id=data['course_id'],
            title=data['title'],
            description=data.get('description', ''),
            time_limit=data.get('time_limit'),
            max_attempts=data.get('max_attempts', 1),
            max_score=float(data['max_score'])
        )
        db.session.add(test)
        db.session.commit()

        # Создаем вопросы
        for question_data in data.get('questions', []):
            question = TestQuestion(
                test_id=test.id,
                question_text=question_data['text'],
                question_type=question_data.get('type', 'multiple_choice'),
                max_score=float(question_data.get('max_score', 1.0)),
                order_index=question_data.get('order', 0)
            )
            db.session.add(question)
            db.session.flush()

            # Создаем варианты ответов
            for option_data in question_data.get('options', []):
                option = TestOption(
                    question_id=question.id,
                    option_text=option_data['text'],
                    is_correct=option_data.get('is_correct', False),
                    order_index=option_data.get('order', 0)
                )
                db.session.add(option)

        db.session.commit()
        log_change('test', test.id, 'create', f'Тест "{test.title}" создан', session['user']['id'])
        return jsonify({'success': True, 'test_id': test.id})

    courses = get_teacher_courses(session['user']['id'])
    return render_template('teacher/test_create.html',
                           user=session['user'],
                           courses=courses)


@app.route('/teacher/test/<int:test_id>/delete', methods=['POST'])
def teacher_delete_test(test_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    test = Test.query.get_or_404(test_id)
    course = Course.query.get_or_404(test.course_id)

    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        # Удаляем вопросы и варианты ответов
        for question in test.questions:
            for option in question.options:
                db.session.delete(option)
            db.session.delete(question)

        db.session.delete(test)
        db.session.commit()

        log_change('test', test_id, 'delete', f'Тест "{test.title}" удален', session['user']['id'])
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Маршруты для управления группами
@app.route('/teacher/group/create', methods=['POST'])
def teacher_create_group():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json()
    course = Course.query.get_or_404(data['course_id'])

    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        group = Group(
            course_id=data['course_id'],
            name=data['name']
        )
        db.session.add(group)
        db.session.commit()

        log_change('group', group.id, 'create', f'Группа "{group.name}" создана', session['user']['id'])
        return jsonify({'success': True, 'group_id': group.id})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/teacher/group/<int:group_id>/add_student', methods=['POST'])
def teacher_add_student_to_group(group_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    group = Group.query.get_or_404(group_id)
    course = Course.query.get_or_404(group.course_id)

    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        data = request.get_json()
        student_email = data['student_email']

        student = User.query.filter_by(email=student_email, role='student').first()
        if not student:
            return jsonify({'error': 'Студент с таким email не найден'}), 404

        # Проверяем, не состоит ли студент уже в группе
        existing = GroupStudent.query.filter_by(group_id=group_id, student_id=student.id).first()
        if existing:
            return jsonify({'error': 'Студент уже в этой группе'}), 400

        group_student = GroupStudent(
            group_id=group_id,
            student_id=student.id
        )
        db.session.add(group_student)
        db.session.commit()

        log_change('group_student', group_student.id, 'create',
                   f'Студент {student.full_name} добавлен в группу "{group.name}"', session['user']['id'])
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/teacher/group/<int:group_id>/students')
def teacher_group_students(group_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    group = Group.query.get_or_404(group_id)
    course = Course.query.get_or_404(group.course_id)

    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_groups'))

    students = db.session.query(User).join(GroupStudent).filter(GroupStudent.group_id == group_id).all()

    return render_template('teacher/group_students.html',
                           user=session['user'],
                           group=group,
                           course=course,
                           students=students)


# Маршруты для оценок
@app.route('/teacher/course/<int:course_id>/grades')
def teacher_course_grades(course_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    course = db.session.get(Course, course_id)
    if not course:
        flash('Курс не найден', 'error')
        return redirect(url_for('teacher_grades'))

    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_grades'))

    try:
        # Получаем студентов курса через группы
        students = db.session.query(User).join(GroupStudent).join(Group).filter(
            Group.course_id == course_id
        ).distinct().all()

        # Получаем задания курса
        assignments = Assignment.query.filter_by(course_id=course_id).order_by(Assignment.created_at).all()

        # Получаем оценки
        grades_data = []
        for student in students:
            student_grades = []
            for assignment in assignments:
                submission = AssignmentSubmission.query.filter_by(
                    assignment_id=assignment.id,
                    student_id=student.id
                ).first()
                student_grades.append({
                    'assignment': assignment,
                    'submission': submission,
                    'score': submission.score if submission else None
                })

            grades_data.append({
                'student': student,
                'grades': student_grades
            })

        return render_template('teacher/course_grades.html',
                               user=session['user'],
                               course=course,
                               assignments=assignments,
                               grades_data=grades_data)
    except Exception as e:
        flash(f'Ошибка при загрузке оценок: {str(e)}', 'error')
        return redirect(url_for('teacher_grades'))


@app.route('/teacher/grades/export/<int:course_id>')
def teacher_export_grades(course_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    course = Course.query.get_or_404(course_id)
    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_grades'))

    # Здесь будет логика экспорта в CSV/Excel
    # Пока просто редирект
    flash('Функция экспорта будет реализована в следующем обновлении', 'info')
    return redirect(url_for('teacher_course_grades', course_id=course_id))


@app.route('/teacher/assignment/<int:assignment_id>/submissions')
def teacher_assignment_submissions(assignment_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    assignment = Assignment.query.get_or_404(assignment_id)
    course = Course.query.get_or_404(assignment.course_id)

    if course.teacher_id != session['user']['id']:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('teacher_assignments'))

    # Получаем все работы по этому заданию
    submissions = AssignmentSubmission.query.filter_by(
        assignment_id=assignment_id
    ).order_by(AssignmentSubmission.submitted_at.desc()).all()

    return render_template('teacher/assignment_submissions.html',
                           user=session['user'],
                           assignment=assignment,
                           course=course,
                           submissions=submissions)


# Вспомогательные функции для шаблонов
@app.context_processor
def utility_processor():
    def get_course_by_id(course_id):
        return Course.query.get(course_id)

    def get_assignment_by_id(assignment_id):
        return Assignment.query.get(assignment_id)

    def get_user_by_id(user_id):
        return User.query.get(user_id)

    def get_course_stats(course_id):
        """Получает статистику курса"""
        try:
            # Количество уникальных студентов в курсе (через группы)
            students_count = db.session.query(GroupStudent).join(Group).filter(
                Group.course_id == course_id
            ).distinct(GroupStudent.student_id).count()

            # Количество заданий в курсе
            assignments_count = Assignment.query.filter_by(course_id=course_id).count()

            # Количество всех отправленных работ в курсе
            submissions_count = AssignmentSubmission.query.join(Assignment).filter(
                Assignment.course_id == course_id
            ).count()

            # Расчет среднего балла по ВСЕМ проверенным работам курса
            graded_submissions = AssignmentSubmission.query.join(Assignment).filter(
                Assignment.course_id == course_id,
                AssignmentSubmission.score.isnot(None)
            ).all()

            average_score = 0
            if graded_submissions:
                total_score = sum(sub.score for sub in graded_submissions if sub.score is not None)
                average_score = total_score / len(graded_submissions)

            return {
                'students_count': students_count,
                'average_score': round(average_score, 1),
                'assignments_count': assignments_count,
                'submissions_count': submissions_count
            }
        except Exception as e:
            print(f"Ошибка в get_course_stats для курса {course_id}: {e}")
            return {
                'students_count': 0,
                'average_score': 0,
                'assignments_count': 0,
                'submissions_count': 0
            }

    def get_graded_submissions_count(course_id):
        """Получает количество проверенных работ для курса"""
        try:
            return AssignmentSubmission.query.join(Assignment).filter(
                Assignment.course_id == course_id,
                AssignmentSubmission.score.isnot(None)
            ).count()
        except Exception as e:
            print(f"Ошибка в get_graded_submissions_count: {e}")
            return 0

    def get_current_time():
        return datetime.utcnow()

    def get_grade_color(score, max_score=100):
        """Возвращает цвет для отображения оценки в 100-балльной системе"""
        if score is None:
            return 'secondary'

        percentage = (score / max_score) * 100

        if percentage >= 85:
            return 'success'  # зеленый - отлично
        elif percentage >= 70:
            return 'info'  # синий - хорошо
        elif percentage >= 60:
            return 'warning'  # желтый - удовлетворительно
        else:
            return 'danger'  # красный - неудовлетворительно

    return dict(
        get_course_by_id=get_course_by_id,
        get_assignment_by_id=get_assignment_by_id,
        get_user_by_id=get_user_by_id,
        get_course_stats=get_course_stats,
        get_graded_submissions_count=get_graded_submissions_count,
        get_grade_color=get_grade_color,
        now=get_current_time
    )


def get_grade_color(score, max_score=100):
    """Возвращает цвет для отображения оценки в 100-балльной системе"""
    if score is None:
        return 'secondary'

    percentage = (score / max_score) * 100

    if percentage >= 85:
        return 'success'  # зеленый - отлично
    elif percentage >= 70:
        return 'info'  # синий - хорошо
    elif percentage >= 60:
        return 'warning'  # желтый - удовлетворительно
    else:
        return 'danger'  # красный - неудовлетворительно


# Маршруты для уведомлений
@app.route('/api/notifications')
def api_notifications():
    if 'user' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    user_id = session['user']['id']
    notifications = get_user_notifications(user_id, limit=20)

    notifications_data = []
    for notification in notifications:
        notifications_data.append({
            'id': notification.id,
            'title': notification.title,
            'message': notification.message,
            'type': notification.type,
            'is_read': notification.is_read,
            'created_at': notification.created_at.strftime('%d.%m.%Y %H:%M'),
            'related_entity_type': notification.related_entity_type,
            'related_entity_id': notification.related_entity_id
        })

    unread_count = get_unread_notifications_count(user_id)

    return jsonify({
        'notifications': notifications_data,
        'unread_count': unread_count
    })


@app.route('/api/notifications/<int:notification_id>/read', methods=['POST'])
def api_mark_notification_read(notification_id):
    if 'user' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    user_id = session['user']['id']

    if mark_notification_as_read(notification_id, user_id):
        return jsonify({'success': True})
    else:
        return jsonify({'error': 'Уведомление не найдено'}), 404


@app.route('/api/notifications/read_all', methods=['POST'])
def api_mark_all_notifications_read():
    if 'user' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    user_id = session['user']['id']
    mark_all_notifications_as_read(user_id)

    return jsonify({'success': True})


# --- API Routes for Telegram Bot Integration ---

@app.route('/api/link_telegram', methods=['POST'])
def link_telegram():
    data = request.get_json()
    user_id = data.get('user_id')
    telegram_id = data.get('telegram_id')

    if not user_id or not telegram_id:
        return jsonify({"error": "Missing user_id or telegram_id"}), 400

    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    user.telegram_id = telegram_id
    db.session.commit()

    return jsonify({"message": "Telegram ID linked successfully"}), 200


@app.route('/api/recommendations/<int:lms_user_id>', methods=['GET'])
def get_recommendations(lms_user_id):
    user = User.query.get(lms_user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404

    # Fetch NEW recommendations that haven't been sent to Telegram
    recommendations = Recommendation.query.filter_by(
        user_id=lms_user_id,
        status='NEW',
        telegram_sent=False
    ).all()

    result = []
    for rec in recommendations:
        result.append({
            "id": rec.id,
            "message": rec.message,
            "action_link": rec.action_link,
            "type": rec.type,
            "created_at": rec.created_at.isoformat()
        })
        # Mark as sent to Telegram immediately to avoid sending duplicates
        rec.telegram_sent = True

    db.session.commit()

    return jsonify(result), 200


@app.route('/api/recommendation/<int:rec_id>/mark_done', methods=['POST'])
def mark_recommendation_done(rec_id):
    recommendation = Recommendation.query.get(rec_id)
    if not recommendation:
        return jsonify({"error": "Recommendation not found"}), 404

    recommendation.status = 'DONE'
    db.session.commit()

    return jsonify({"message": f"Recommendation {rec_id} marked as DONE"}), 200


# --- End API Routes ---

@app.route('/notifications')
def notifications_page():
    if 'user' not in session:
        return redirect(url_for('login'))

    user_id = session['user']['id']
    notifications = get_user_notifications(user_id, limit=50)
    unread_count = get_unread_notifications_count(user_id)

    return render_template('notifications.html',
                           user=session['user'],
                           notifications=notifications,
                           unread_count=unread_count)


@app.route('/api/teacher/create_assignment', methods=['POST'])
def api_create_assignment():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    try:
        data = request.get_json()

        # Проверяем, что курс принадлежит преподавателю
        course = Course.query.get(data['course_id'])
        if not course or course.teacher_id != session['user']['id']:
            return jsonify({'error': 'Доступ запрещен'}), 403

        assignment = Assignment(
            course_id=data['course_id'],
            title=data['title'],
            description=data.get('description', ''),
            max_score=float(data['max_score']),
            due_date=datetime.fromisoformat(data['due_date']) if data.get('due_date') else None,
            allow_resubmission=data.get('allow_resubmission', True)
        )
        db.session.add(assignment)
        db.session.commit()

        # Создаем уведомление для преподавателя
        create_notification(
            user_id=session['user']['id'],
            title='Задание создано',
            message=f'Задание "{assignment.title}" успешно создано в курсе "{course.title}"',
            type='success',
            related_entity_type='assignment',
            related_entity_id=assignment.id
        )

        log_change('assignment', assignment.id, 'create', f'Задание "{assignment.title}" создано',
                   session['user']['id'])

        return jsonify({'success': True, 'assignment_id': assignment.id})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@app.route('/api/teacher/assignment/<int:assignment_id>/delete', methods=['POST'])
def api_delete_assignment(assignment_id):
    if 'user' not in session or session['user']['role'] != 'teacher':
        return jsonify({'error': 'Unauthorized'}), 401

    assignment = Assignment.query.get_or_404(assignment_id)
    course = Course.query.get_or_404(assignment.course_id)

    if course.teacher_id != session['user']['id']:
        return jsonify({'error': 'Доступ запрещен'}), 403

    try:
        # СОЗДАЕМ УВЕДОМЛЕНИЕ ОБ УДАЛЕНИИ ЗАДАНИЯ
        create_notification(
            user_id=session['user']['id'],
            title='Задание удалено',
            message=f'Задание "{assignment.title}" удалено из курса "{course.title}"',
            type='warning',
            related_entity_type='assignment',
            related_entity_id=assignment_id
        )

        # Удаляем связанные данные
        submissions = AssignmentSubmission.query.filter_by(assignment_id=assignment_id).all()
        for submission in submissions:
            # Удаляем комментарии к отправкам
            SubmissionComment.query.filter_by(submission_id=submission.id).delete()
            db.session.delete(submission)

        db.session.delete(assignment)
        db.session.commit()

        log_change('assignment', assignment_id, 'delete', f'Задание "{assignment.title}" удалено',
                   session['user']['id'])
        return jsonify({'success': True})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@app.route('/teacher/all_grades')
def teacher_all_grades():
    if 'user' not in session or session['user']['role'] != 'teacher':
        return redirect(url_for('dashboard'))

    user = session['user']
    courses = get_teacher_courses(user['id'])

    # Собираем все оценки по всем курсам
    all_grades_data = []
    for course in courses:
        # Получаем студентов курса через группы
        students = db.session.query(User).join(GroupStudent).join(Group).filter(
            Group.course_id == course.id
        ).distinct().all()

        # Получаем задания курса
        assignments = Assignment.query.filter_by(course_id=course.id).order_by(Assignment.created_at).all()

        # Получаем оценки для этого курса
        course_grades = []
        for student in students:
            student_grades = []
            total_student_score = 0
            total_max_score = 0
            graded_assignments_count = 0

            for assignment in assignments:
                submission = AssignmentSubmission.query.filter_by(
                    assignment_id=assignment.id,
                    student_id=student.id
                ).first()

                score = submission.score if submission else None
                student_grades.append({
                    'assignment': assignment,
                    'submission': submission,
                    'score': score
                })

                if score is not None:
                    total_student_score += score
                    total_max_score += assignment.max_score
                    graded_assignments_count += 1

            # Рассчитываем средний балл студента
            average_score = (total_student_score / total_max_score * 100) if total_max_score > 0 else 0

            course_grades.append({
                'student': student,
                'grades': student_grades,
                'average_score': round(average_score, 1),
                'graded_assignments_count': graded_assignments_count,
                'total_assignments_count': len(assignments)
            })

        all_grades_data.append({
            'course': course,
            'grades': course_grades,
            'assignments': assignments
        })

    return render_template('teacher/all_grades.html',
                           user=session['user'],
                           all_grades_data=all_grades_data,
                           courses=courses)

# Initialize API routes for Telegram bot integration
# from api_routes import init_api_routes
# init_api_routes(app, db, User, Course, Assignment, AssignmentSubmission,
#                 Notification, Recommendation, GroupStudent)

if __name__ == '__main__':
    print("Инициализация базы данных...")
    with app.app_context():
        db.create_all()  # Создание таблиц, включая Event и Recommendation

    print("\n" + "=" * 50)
    print("LMS Platform для преподавателей запускается...")
    print("Демо доступ преподавателя: teacher@demo.ru / 123")
    print("API endpoints доступны на /api/*")
    print("=" * 50 + "\n")

    app.run(debug=True, host='0.0.0.0', port=5000)