# -*- coding: utf-8 -*-
"""
API Routes for Telegram Bot Integration
Provides REST API endpoints for the Telegram bot to interact with the LMS platform
"""
from flask import Blueprint, request, jsonify
from functools import wraps

# API Blueprint
api_bp = Blueprint('api', __name__, url_prefix='/api')

# API Key authentication
def require_api_key(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get('X-API-Key')
        # В production используйте безопасный ключ из переменных окружения
        if api_key != 'lms_secret_key_for_bot':
            return jsonify({'error': 'Invalid API key'}), 401
        return f(*args, **kwargs)
    return decorated_function

def init_api_routes(app, db, User, Course, Assignment, AssignmentSubmission, 
                     Notification, Recommendation, GroupStudent):
    """Initialize API routes with app context"""
    
    @api_bp.route('/health', methods=['GET'])
    def health_check():
        """Health check endpoint"""
        return jsonify({'status': 'ok', 'service': 'LMS API'}), 200
    
    @api_bp.route('/user/by_telegram/<int:telegram_id>', methods=['GET'])
    @require_api_key
    def get_user_by_telegram(telegram_id):
        """Get user information by Telegram ID"""
        user = User.query.filter_by(telegram_id=telegram_id).first()
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        return jsonify({
            'id': user.id,
            'email': user.email,
            'full_name': user.full_name,
            'role': user.role,
            'telegram_id': user.telegram_id,
            'is_active': user.is_active
        }), 200
    
    @api_bp.route('/user/<int:user_id>/courses', methods=['GET'])
    @require_api_key
    def get_user_courses(user_id):
        """Get all courses for a user"""
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        courses = []
        if user.role == 'teacher':
            # Преподаватель видит свои курсы
            courses = Course.query.filter_by(teacher_id=user_id, is_archived=False).all()
        else:
            # Студент видит курсы, в которых он состоит через группы
            group_memberships = GroupStudent.query.filter_by(student_id=user_id).all()
            course_ids = [gm.group.course_id for gm in group_memberships]
            courses = Course.query.filter(Course.id.in_(course_ids), Course.is_archived == False).all()
        
        result = []
        for course in courses:
            result.append({
                'id': course.id,
                'title': course.title,
                'description': course.description,
                'teacher_name': course.teacher.full_name,
                'is_active': course.is_active
            })
        
        return jsonify(result), 200
    
    @api_bp.route('/user/<int:user_id>/assignments', methods=['GET'])
    @require_api_key
    def get_user_assignments(user_id):
        """Get all assignments for a user"""
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        assignments = []
        if user.role == 'teacher':
            # Преподаватель видит задания своих курсов
            courses = Course.query.filter_by(teacher_id=user_id).all()
            for course in courses:
                assignments.extend(course.assignments)
        else:
            # Студент видит задания курсов, в которых он состоит
            group_memberships = GroupStudent.query.filter_by(student_id=user_id).all()
            course_ids = [gm.group.course_id for gm in group_memberships]
            assignments = Assignment.query.filter(Assignment.course_id.in_(course_ids)).all()
        
        result = []
        for assignment in assignments:
            # Получаем статус отправки для студента
            submission = None
            if user.role == 'student':
                submission = AssignmentSubmission.query.filter_by(
                    assignment_id=assignment.id,
                    student_id=user_id
                ).order_by(AssignmentSubmission.submitted_at.desc()).first()
            
            result.append({
                'id': assignment.id,
                'title': assignment.title,
                'description': assignment.description,
                'course_title': assignment.course.title,
                'max_score': assignment.max_score,
                'due_date': assignment.due_date.isoformat() if assignment.due_date else None,
                'status': submission.status if submission else 'not_submitted',
                'score': submission.score if submission else None
            })
        
        return jsonify(result), 200
    
    @api_bp.route('/user/<int:user_id>/deadlines', methods=['GET'])
    @require_api_key
    def get_user_deadlines(user_id):
        """Get upcoming deadlines for a user"""
        from datetime import datetime, timedelta
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Получаем задания с дедлайнами в ближайшие 30 дней
        now = datetime.utcnow()
        future = now + timedelta(days=30)
        
        if user.role == 'student':
            group_memberships = GroupStudent.query.filter_by(student_id=user_id).all()
            course_ids = [gm.group.course_id for gm in group_memberships]
            assignments = Assignment.query.filter(
                Assignment.course_id.in_(course_ids),
                Assignment.due_date.isnot(None),
                Assignment.due_date >= now,
                Assignment.due_date <= future
            ).order_by(Assignment.due_date).all()
        else:
            courses = Course.query.filter_by(teacher_id=user_id).all()
            course_ids = [c.id for c in courses]
            assignments = Assignment.query.filter(
                Assignment.course_id.in_(course_ids),
                Assignment.due_date.isnot(None),
                Assignment.due_date >= now,
                Assignment.due_date <= future
            ).order_by(Assignment.due_date).all()
        
        result = []
        for assignment in assignments:
            result.append({
                'id': assignment.id,
                'title': assignment.title,
                'course_title': assignment.course.title,
                'due_date': assignment.due_date.isoformat(),
                'days_left': (assignment.due_date - now).days
            })
        
        return jsonify(result), 200
    
    @api_bp.route('/user/<int:user_id>/grades', methods=['GET'])
    @require_api_key
    def get_user_grades(user_id):
        """Get all grades for a student"""
        user = User.query.get(user_id)
        if not user or user.role != 'student':
            return jsonify({'error': 'User not found or not a student'}), 404
        
        submissions = AssignmentSubmission.query.filter_by(
            student_id=user_id,
            status='graded'
        ).order_by(AssignmentSubmission.graded_at.desc()).all()
        
        result = []
        for submission in submissions:
            result.append({
                'assignment_title': submission.assignment.title,
                'course_title': submission.assignment.course.title,
                'score': submission.score,
                'max_score': submission.assignment.max_score,
                'percentage': (submission.score / submission.assignment.max_score * 100) if submission.score else 0,
                'graded_at': submission.graded_at.isoformat() if submission.graded_at else None
            })
        
        return jsonify(result), 200
    
    @api_bp.route('/recommendations/<int:user_id>', methods=['GET'])
    @require_api_key
    def get_recommendations(user_id):
        """Get new recommendations for a user"""
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Fetch NEW recommendations that haven't been sent to Telegram
        recommendations = Recommendation.query.filter_by(
            user_id=user_id,
            status='NEW',
            telegram_sent=False
        ).all()
        
        result = []
        for rec in recommendations:
            result.append({
                'id': rec.id,
                'message': rec.message,
                'action_link': rec.action_link,
                'type': rec.type,
                'created_at': rec.created_at.isoformat()
            })
            # Mark as sent to Telegram to avoid duplicates
            rec.telegram_sent = True
        
        db.session.commit()
        
        return jsonify(result), 200
    
    @api_bp.route('/recommendation/<int:rec_id>/mark_done', methods=['POST'])
    @require_api_key
    def mark_recommendation_done(rec_id):
        """Mark a recommendation as done"""
        recommendation = Recommendation.query.get(rec_id)
        if not recommendation:
            return jsonify({'error': 'Recommendation not found'}), 404
        
        recommendation.status = 'DONE'
        db.session.commit()
        
        return jsonify({'message': f'Recommendation {rec_id} marked as DONE'}), 200
    
    @api_bp.route('/link_telegram', methods=['POST'])
    @require_api_key
    def link_telegram():
        """Link a Telegram ID to a user account"""
        data = request.get_json()
        user_id = data.get('user_id')
        telegram_id = data.get('telegram_id')
        
        if not user_id or not telegram_id:
            return jsonify({'error': 'Missing user_id or telegram_id'}), 400
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Проверяем, не привязан ли уже этот telegram_id к другому пользователю
        existing_user = User.query.filter_by(telegram_id=telegram_id).first()
        if existing_user and existing_user.id != user_id:
            return jsonify({'error': 'This Telegram ID is already linked to another user'}), 400
        
        user.telegram_id = telegram_id
        db.session.commit()
        
        return jsonify({'message': 'Telegram ID linked successfully', 'user': {
            'id': user.id,
            'full_name': user.full_name,
            'email': user.email,
            'role': user.role
        }}), 200
    
    @api_bp.route('/user/<int:user_id>/notifications', methods=['GET'])
    @require_api_key
    def get_user_notifications(user_id):
        """Get notifications for a user"""
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        limit = request.args.get('limit', 10, type=int)
        notifications = Notification.query.filter_by(user_id=user_id).order_by(
            Notification.created_at.desc()
        ).limit(limit).all()
        
        result = []
        for notif in notifications:
            result.append({
                'id': notif.id,
                'title': notif.title,
                'message': notif.message,
                'type': notif.type,
                'is_read': notif.is_read,
                'created_at': notif.created_at.isoformat()
            })
        
        return jsonify(result), 200
    
    # Register blueprint
    app.register_blueprint(api_bp)
    
    return api_bp
