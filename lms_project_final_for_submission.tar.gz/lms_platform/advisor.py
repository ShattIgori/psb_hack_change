# -*- coding: utf-8 -*-
from datetime import datetime, timedelta
from app import db, User, Course, Assignment, Test, Recommendation, Event

def run_recommendation_engine():
    """Основная функция для запуска движка рекомендаций."""
    print("Запуск движка рекомендаций...")
    users = User.query.filter(User.is_active == True).all()
    for user in users:
        # Правило 1: "Застрял на модуле"
        check_stuck_on_module(user)

        # Правило 2: "Проблемы с темой"
        check_failed_tests(user)

        # Правило 3: "Последний рывок к дедлайну"
        check_deadline_approaching(user)

    # Правила для преподавателей
    teachers = User.query.filter_by(role=\'teacher\', is_active=True).all()
    for teacher in teachers:
        # Правило 4: "Группа риска"
        check_group_at_risk(teacher)

        # Правило 5: "Проваленный тест"
        check_failed_group_tests(teacher)

def check_stuck_on_module(user):
    """Если студент не заходил в курс > 3 дней И дедлайн приближается -> рекомендация."""
    # Примерная логика, требует доработки
    pass

def check_failed_tests(user):
    """Если результат по тесту < 60% -> рекомендация."""
    # Примерная логика, требует доработки
    pass

def check_deadline_approaching(user):
    """За 24 часа до дедлайна, если нет ни одной отправки по заданию -> рекомендация."""
    now = datetime.utcnow()
    deadline_threshold = now + timedelta(days=1)

    # Находим все курсы, на которые подписан студент
    # ... (нужна реализация связи студент-курс)

    # Временная заглушка: проверяем все активные задания
    assignments = Assignment.query.filter(Assignment.due_date <= deadline_threshold, Assignment.due_date > now).all()
    for assignment in assignments:
        submission = AssignmentSubmission.query.filter_by(student_id=user.id, assignment_id=assignment.id).first()
        if not submission:
            # Проверяем, не создана ли уже такая рекомендация
            existing_rec = Recommendation.query.filter_by(
                user_id=user.id, 
                type=\'DO_ASSIGNMENT\', 
                status=\'NEW\'
            ).first()

            if not existing_rec:
                rec = Recommendation(
                    user_id=user.id,
                    course_id=assignment.course_id,
                    type=\'DO_ASSIGNMENT\',
                    message=f"Срок сдачи задания \"{assignment.title}\" истекает через 24 часа! Пожалуйста, отправьте свою работу.",
                    action_link=f"/teacher/assignments/{assignment.id}" # Заменить на студентческий URL
                )
                db.session.add(rec)
                print(f"Создана рекомендация для {user.email} по заданию {assignment.title}")

    db.session.commit()

def check_group_at_risk(teacher):
    """Если >30% группы не отправили ДЗ за 24 часа до дедлайна -> рекомендация преподавателю."""
    # Примерная логика, требует доработки
    pass

def check_failed_group_tests(teacher):
    """Если медианный балл по тесту < порога -> рекомендация преподавателю."""
    # Примерная логика, требует доработки
    pass

if __name__ == \'__main__\':
    # Этот блок для локального тестирования модуля
    from app import app
    with app.app_context():
        run_recommendation_engine()
