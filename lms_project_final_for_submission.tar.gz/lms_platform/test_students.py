# test_students.py
# Генерация тестовых данных студентов для LMS системы (100-балльная система)

from app import app, db, User, Course, Group, GroupStudent, Assignment, AssignmentSubmission
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta
import random

def create_test_students():
    """Создает тестовых студентов"""
    print("Создание тестовых студентов...")

    # Список тестовых студентов (увеличим до 50 для большего разнообразия)
    test_students = [
        # Группа 1 - Программирование на Python
        {"email": "student1@demo.ru", "full_name": "Иванов Алексей Сергеевич", "group": "Группа 1"},
        {"email": "student2@demo.ru", "full_name": "Петрова Мария Дмитриевна", "group": "Группа 1"},
        {"email": "student3@demo.ru", "full_name": "Сидоров Андрей Викторович", "group": "Группа 1"},
        {"email": "student4@demo.ru", "full_name": "Кузнецова Елена Игоревна", "group": "Группа 1"},
        {"email": "student5@demo.ru", "full_name": "Васильев Денис Олегович", "group": "Группа 1"},
        {"email": "student6@demo.ru", "full_name": "Николаева Анна Павловна", "group": "Группа 1"},
        {"email": "student7@demo.ru", "full_name": "Морозов Иван Александрович", "group": "Группа 1"},
        {"email": "student8@demo.ru", "full_name": "Орлова Светлана Владимировна", "group": "Группа 1"},
        {"email": "student25@demo.ru", "full_name": "Тихонов Роман Олегович", "group": "Группа 1"},
        {"email": "student28@demo.ru", "full_name": "Медведева Ольга Викторовна", "group": "Группа 1"},
        {"email": "student31@demo.ru", "full_name": "Воронов Артем Сергеевич", "group": "Группа 1"},
        {"email": "student34@demo.ru", "full_name": "Борисова Дарья Андреевна", "group": "Группа 1"},

        # Группа 2 - Веб-разработка
        {"email": "student9@demo.ru", "full_name": "Федоров Максим Сергеевич", "group": "Группа 2"},
        {"email": "student10@demo.ru", "full_name": "Дмитриева Ольга Андреевна", "group": "Группа 2"},
        {"email": "student11@demo.ru", "full_name": "Белов Артем Игоревич", "group": "Группа 2"},
        {"email": "student12@demo.ru", "full_name": "Соколова Татьяна Викторовна", "group": "Группа 2"},
        {"email": "student13@demo.ru", "full_name": "Комаров Павел Денисович", "group": "Группа 2"},
        {"email": "student14@demo.ru", "full_name": "Волкова Ирина Олеговна", "group": "Группа 2"},
        {"email": "student15@demo.ru", "full_name": "Лебедев Сергей Николаевич", "group": "Группа 2"},
        {"email": "student16@demo.ru", "full_name": "Егорова Наталья Михайловна", "group": "Группа 2"},
        {"email": "student26@demo.ru", "full_name": "Абрамова Алина Сергеевна", "group": "Группа 2"},
        {"email": "student29@demo.ru", "full_name": "Сергеев Артем Дмитриевич", "group": "Группа 2"},
        {"email": "student32@demo.ru", "full_name": "Гордеев Илья Викторович", "group": "Группа 2"},
        {"email": "student35@demo.ru", "full_name": "Фролова Ксения Павловна", "group": "Группа 2"},

        # Группа 3 - Базы данных
        {"email": "student17@demo.ru", "full_name": "Новиков Алексей Владимирович", "group": "Группа 3"},
        {"email": "student18@demo.ru", "full_name": "Ковалева Марина Сергеевна", "group": "Группа 3"},
        {"email": "student19@demo.ru", "full_name": "Зайцев Дмитрий Петрович", "group": "Группа 3"},
        {"email": "student20@demo.ru", "full_name": "Семенова Екатерина Алексеевна", "group": "Группа 3"},
        {"email": "student21@demo.ru", "full_name": "Ефимов Антон Юрьевич", "group": "Группа 3"},
        {"email": "student22@demo.ru", "full_name": "Романова Юлия Дмитриевна", "group": "Группа 3"},
        {"email": "student23@demo.ru", "full_name": "Григорьев Виктор Иванович", "group": "Группа 3"},
        {"email": "student24@demo.ru", "full_name": "Жукова Людмила Васильевна", "group": "Группа 3"},
        {"email": "student27@demo.ru", "full_name": "Данилов Кирилл Андреевич", "group": "Группа 3"},
        {"email": "student30@demo.ru", "full_name": "Михайлова Ангелина Игоревна", "group": "Группа 3"},
        {"email": "student33@demo.ru", "full_name": "Крылов Денис Олегович", "group": "Группа 3"},
        {"email": "student36@demo.ru", "full_name": "Маркова Виктория Сергеевна", "group": "Группа 3"},

        # Дополнительные студенты для большего разнообразия
        {"email": "student37@demo.ru", "full_name": "Савельев Максим Игоревич", "group": "Группа 1"},
        {"email": "student38@demo.ru", "full_name": "Полякова Анастасия Владимировна", "group": "Группа 2"},
        {"email": "student39@demo.ru", "full_name": "Гусев Александр Дмитриевич", "group": "Группа 3"},
        {"email": "student40@demo.ru", "full_name": "Киселева Елена Андреевна", "group": "Группа 1"},
        {"email": "student41@demo.ru", "full_name": "Макаров Роман Сергеевич", "group": "Группа 2"},
        {"email": "student42@demo.ru", "full_name": "Федотова Ольга Николаевна", "group": "Группа 3"},
        {"email": "student43@demo.ru", "full_name": "Щербаков Владислав Игоревич", "group": "Группа 1"},
        {"email": "student44@demo.ru", "full_name": "Блинова Татьяна Викторовна", "group": "Группа 2"},
        {"email": "student45@demo.ru", "full_name": "Колесников Артем Олегович", "group": "Группа 3"},
        {"email": "student46@demo.ru", "full_name": "Карпова Ирина Дмитриевна", "group": "Группа 1"},
        {"email": "student47@demo.ru", "full_name": "Афанасьев Павел Андреевич", "group": "Группа 2"},
        {"email": "student48@demo.ru", "full_name": "Власова Мария Сергеевна", "group": "Группа 3"},
        {"email": "student49@demo.ru", "full_name": "Маслов Дмитрий Викторович", "group": "Группа 1"},
        {"email": "student50@demo.ru", "full_name": "Исаева Кристина Олеговна", "group": "Группа 2"},
    ]

    created_students = []

    for student_data in test_students:
        # Проверяем, существует ли студент
        existing_student = User.query.filter_by(email=student_data["email"]).first()
        if not existing_student:
            student = User(
                email=student_data["email"],
                password_hash=generate_password_hash("123"),  # одинаковый пароль для всех тестовых студентов
                full_name=student_data["full_name"],
                role='student',
                is_active=True
            )
            db.session.add(student)
            created_students.append(student_data)

    db.session.commit()
    print(f"Создано {len(created_students)} тестовых студентов")
    return created_students

def assign_students_to_groups():
    """Распределяет студентов по группам"""
    print("Распределение студентов по группам...")

    # Получаем курсы преподавателя
    teacher = User.query.filter_by(email='teacher@demo.ru').first()
    if not teacher:
        print("Преподаватель не найден!")
        return

    courses = Course.query.filter_by(teacher_id=teacher.id).all()

    # Создаем группы для каждого курса
    groups_created = 0
    for course in courses:
        # Создаем 3 группы для каждого курса
        for i in range(1, 4):
            group_name = f"Группа {i}"
            existing_group = Group.query.filter_by(course_id=course.id, name=group_name).first()

            if not existing_group:
                group = Group(
                    course_id=course.id,
                    name=group_name
                )
                db.session.add(group)
                groups_created += 1

    db.session.commit()
    print(f"Создано {groups_created} групп")

    # Распределяем студентов по группам
    assignments_created = 0

    # Получаем всех студентов
    students = User.query.filter_by(role='student').all()

    for student in students:
        # Находим email студента в тестовых данных
        student_email = student.email

        # Определяем группу студента на основе email
        group_number = None
        student_num = int(student_email.replace("student", "").replace("@demo.ru", ""))

        if student_num in [1, 2, 3, 4, 5, 6, 7, 8, 25, 28, 31, 34, 37, 40, 43, 46, 49]:
            group_number = 1
        elif student_num in [9, 10, 11, 12, 13, 14, 15, 16, 26, 29, 32, 35, 38, 41, 44, 47, 50]:
            group_number = 2
        elif student_num in [17, 18, 19, 20, 21, 22, 23, 24, 27, 30, 33, 36, 39, 42, 45, 48]:
            group_number = 3

        if group_number:
            # Находим группу для каждого курса
            for course in courses:
                group = Group.query.filter_by(course_id=course.id, name=f"Группа {group_number}").first()
                if group:
                    # Проверяем, не состоит ли студент уже в группе
                    existing_assignment = GroupStudent.query.filter_by(
                        group_id=group.id,
                        student_id=student.id
                    ).first()

                    if not existing_assignment:
                        group_student = GroupStudent(
                            group_id=group.id,
                            student_id=student.id
                        )
                        db.session.add(group_student)
                        assignments_created += 1

    db.session.commit()
    print(f"Создано {assignments_created} назначений студентов в группы")

def create_test_assignments_and_submissions():
    """Создает тестовые задания и отправки работ (100-балльная система)"""
    print("Создание тестовых заданий и работ...")

    # Получаем курсы преподавателя
    teacher = User.query.filter_by(email='teacher@demo.ru').first()
    courses = Course.query.filter_by(teacher_id=teacher.id).all()

    # Создаем задания для каждого курса (все по 100 баллов)
    assignments_data = [
        {
            "title": "Введение в программирование",
            "description": "Напишите первую программу 'Hello World'. Опишите базовые концепции программирования.",
            "max_score": 100.0,
            "due_date_days": 7
        },
        {
            "title": "Работа с переменными и типами данных",
            "description": "Создайте программу, демонстрирующую работу с различными типами данных и операциями.",
            "max_score": 100.0,
            "due_date_days": 14
        },
        {
            "title": "Условные операторы и циклы",
            "description": "Реализуйте программу с использованием условных операторов и циклов для решения практической задачи.",
            "max_score": 100.0,
            "due_date_days": 21
        },
        {
            "title": "Функции и модули",
            "description": "Разработайте модуль с набором функций для решения конкретной проблемы.",
            "max_score": 100.0,
            "due_date_days": 28
        },
        {
            "title": "Итоговый проект курса",
            "description": "Разработайте полноценное приложение, демонстрирующее все изученные концепции курса.",
            "max_score": 100.0,
            "due_date_days": 35
        },
        {
            "title": "Контрольная работа №1",
            "description": "Теоретические вопросы и практические задания по пройденному материалу.",
            "max_score": 100.0,
            "due_date_days": 10
        },
        {
            "title": "Контрольная работа №2",
            "description": "Промежуточная аттестация по основным темам курса.",
            "max_score": 100.0,
            "due_date_days": 25
        }
    ]

    assignments_created = 0
    submissions_created = 0

    for course in courses:
        for assignment_data in assignments_data:
            # Проверяем, существует ли задание
            existing_assignment = Assignment.query.filter_by(
                course_id=course.id,
                title=assignment_data["title"]
            ).first()

            if not existing_assignment:
                assignment = Assignment(
                    course_id=course.id,
                    title=assignment_data["title"],
                    description=assignment_data["description"],
                    max_score=assignment_data["max_score"],
                    due_date=datetime.utcnow() + timedelta(days=assignment_data["due_date_days"]),
                    allow_resubmission=True
                )
                db.session.add(assignment)
                assignments_created += 1

                # Создаем отправки работ от студентов
                course_students = db.session.query(User).join(GroupStudent).join(Group).filter(
                    Group.course_id == course.id
                ).all()

                for student in course_students:
                    # Случайным образом определяем, отправил ли студент работу
                    if random.random() > 0.15:  # 85% студентов отправляют работы
                        submission_status = 'submitted'
                        if random.random() > 0.4:  # 60% работ проверены
                            submission_status = 'graded'

                        # Создаем содержимое работы
                        content_samples = [
                            f"Выполнил задание '{assignment_data['title']}'. В процессе работы использовал изученные материалы курса.",
                            f"Отправляю решение задания '{assignment_data['title']}'. Столкнулся с некоторыми трудностями, но в целом справился.",
                            f"Выполнение задания '{assignment_data['title']}' завершено. Буду рад обратной связи от преподавателя.",
                            f"Представляю свою работу по заданию '{assignment_data['title']}'. Постарался реализовать все требования.",
                            f"Отправляю решение. Задание '{assignment_data['title']}' оказалось интересным и познавательным.",
                            f"Выполнил работу в соответствии с требованиями задания '{assignment_data['title']}'.",
                            f"Представляю на проверку задание '{assignment_data['title']}'. Надеюсь на положительную оценку."
                        ]

                        submission = AssignmentSubmission(
                            assignment_id=assignment.id,
                            student_id=student.id,
                            content=random.choice(content_samples),
                            status=submission_status,
                            submitted_at=datetime.utcnow() - timedelta(
                                days=random.randint(1, assignment_data["due_date_days"] - 1))
                        )

                        # Если работа проверена, ставим оценку по 100-балльной системе
                        if submission_status == 'graded':
                            # Генерируем реалистичные оценки с нормальным распределением
                            # Средняя оценка около 75 баллов
                            base_score = random.normalvariate(75, 15)
                            # Ограничиваем диапазон от 40 до 100 баллов
                            base_score = max(40, min(100, base_score))
                            # Округляем до целого числа
                            submission.score = round(base_score)
                            submission.graded_at = datetime.utcnow()

                        db.session.add(submission)
                        submissions_created += 1

    db.session.commit()
    print(f"Создано {assignments_created} заданий (все по 100 баллов)")
    print(f"Создано {submissions_created} отправок работ")

def create_additional_courses():
    """Создает дополнительные курсы для преподавателя"""
    print("Создание дополнительных курсов...")

    teacher = User.query.filter_by(email='teacher@demo.ru').first()

    additional_courses = [
        {
            "title": "Веб-разработка на Python и Django",
            "description": "Полный курс по созданию веб-приложений с использованием Django фреймворка. Изучение моделей, представлений, шаблонов и ORM."
        },
        {
            "title": "Базы данных и SQL",
            "description": "Изучение реляционных баз данных, SQL запросов, проектирования БД и оптимизации. Практическая работа с PostgreSQL и MySQL."
        },
        {
            "title": "Frontend разработка",
            "description": "Создание современных пользовательских интерфейсов с HTML5, CSS3, JavaScript и фреймворками React/Vue."
        },
        {
            "title": "Машинное обучение на Python",
            "description": "Введение в машинное обучение с использованием библиотек scikit-learn, pandas, numpy. Классификация, регрессия, кластеризация."
        },
        {
            "title": "Мобильная разработка",
            "description": "Создание мобильных приложений для iOS и Android с использованием Flutter и React Native."
        },
        {
            "title": "Алгоритмы и структуры данных",
            "description": "Изучение основных алгоритмов, структур данных и их практическое применение. Сложность алгоритмов, оптимизация."
        },
        {
            "title": "DevOps и развертывание приложений",
            "description": "Автоматизация развертывания, контейнеризация с Docker, оркестрация с Kubernetes, CI/CD пайплайны."
        }
    ]

    courses_created = 0

    for course_data in additional_courses:
        existing_course = Course.query.filter_by(
            teacher_id=teacher.id,
            title=course_data["title"]
        ).first()

        if not existing_course:
            course = Course(
                title=course_data["title"],
                description=course_data["description"],
                teacher_id=teacher.id
            )
            db.session.add(course)
            courses_created += 1

    db.session.commit()
    print(f"Создано {courses_created} дополнительных курсов")

def generate_test_data():
    """Генерирует все тестовые данные"""
    print("Начало генерации тестовых данных (100-балльная система)...")
    print("=" * 50)

    with app.app_context():
        # Создаем тестовых студентов
        created_students = create_test_students()

        # Создаем дополнительные курсы
        create_additional_courses()

        # Распределяем студентов по группам
        assign_students_to_groups()

        # Создаем задания и отправки работ
        create_test_assignments_and_submissions()

        print("=" * 50)
        print("Генерация тестовых данных завершена!")

        # Выводим статистику
        total_students = User.query.filter_by(role='student').count()
        total_courses = Course.query.filter_by(
            teacher_id=User.query.filter_by(email='teacher@demo.ru').first().id).count()
        total_groups = Group.query.count()
        total_assignments = Assignment.query.count()
        total_submissions = AssignmentSubmission.query.count()
        graded_submissions = AssignmentSubmission.query.filter_by(status='graded').count()

        print(f"\n📊 Статистика базы данных:")
        print(f"👨‍🎓 Всего студентов: {total_students}")
        print(f"📚 Всего курсов: {total_courses}")
        print(f"👥 Всего групп: {total_groups}")
        print(f"📝 Всего заданий: {total_assignments}")
        print(f"📤 Всего отправок работ: {total_submissions}")
        print(f"✅ Проверенных работ: {graded_submissions}")

        # Средний балл по всем проверенным работам
        graded_scores = [sub.score for sub in AssignmentSubmission.query.filter_by(status='graded').all() if
                         sub.score is not None]
        if graded_scores:
            avg_score = sum(graded_scores) / len(graded_scores)
            print(f"🏆 Средний балл: {avg_score:.1f}/100")

        print(f"\n🔐 Демо доступы:")
        print(f"👨‍🏫 Преподаватель: teacher@demo.ru / 123")
        print(f"👨‍🎓 Студенты: student1@demo.ru - student50@demo.ru / 123")
        print(f"\n💡 Система оценивания: 100-балльная")
        print(f"📊 Оценки распределены реалистично (в основном 60-90 баллов)")

if __name__ == '__main__':
    generate_test_data()