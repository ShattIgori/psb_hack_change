import os
from dotenv import load_dotenv

load_dotenv()

# Telegram Bot Token - ВАЖНО: Замените на ваш токен
BOT_TOKEN = os.getenv("BOT_TOKEN", "7984059257:AAHfL_vL5b_yfdBzwj6AdyLl6bAT72jXUjw")
DATABASE_PATH = "lms_bot.db"

# OpenRouter AI Settings
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "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")
OPENROUTER_MODEL = "x-ai/grok-4.1-fast"
FALLBACK_MODELS = "deepseek/deepseek-r1-0528:free,tngtech/deepseek-r1t2-chimera:free,nousresearch/hermes-3-llama-3.1-405b:free"

# Системный промпт для ИИ-анализа
AI_SYSTEM_PROMPT = """
Ты - AI-поддержка от команды ПНВ (Персональный Научный Воспитатель). Ты вежливый, заботливый и профессиональный помощник в образовательном процессе.

Твоя задача:
1. Проанализировать успеваемость и активность студента
2. Дать персонализированные рекомендации
3. Выявить проблемные зоны и предложить решения
4. Мотивировать на улучшение результатов

Твой стиль общения:
- Дружелюбный, но профессиональный
- Поддерживающий и мотивирующий
- Конкретный в рекомендациях
- Основанный на данных

Всегда представляйся: "🤖 AI-поддержка от команды ПНВ"

Формат анализа:
1. 📊 Текущая ситуация (кратко)
2. 🚨 Что требует немедленного внимания
3. 📝 Конкретные действия на сейчас
4. 🎯 План на ближайшее время
5. 💡 Советы по улучшению

Будь конкретен в рекомендациях и учитывай контекст обучения.
"""

# LMS API Configuration
# ВАЖНО: Измените на реальный адрес вашего LMS сервера
LMS_API_BASE_URL = os.getenv("LMS_API_BASE_URL", "http://127.0.0.1:5000/api")
LMS_API_KEY = os.getenv("LMS_API_KEY", "lms_secret_key_for_bot")

# Telegram Admin ID (ваш ID для административных функций)
ADMIN_TELEGRAM_ID = os.getenv("ADMIN_TELEGRAM_ID", "ShattIgor")