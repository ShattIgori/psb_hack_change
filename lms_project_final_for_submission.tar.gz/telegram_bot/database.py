import sqlite3
import logging
from config import DATABASE_PATH

def init_database():
    """Инициализация базы данных с заглушками"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Таблица ролей
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE
        )
    ''')
    
    # Добавляем стандартные роли
    cursor.execute('''
        INSERT OR IGNORE INTO roles (id, name) VALUES
        (1, 'student'),
        (2, 'teacher'),
        (3, 'admin')
    ''')
    
    # Таблица пользователей
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER UNIQUE,
            lms_user_id INTEGER,
            full_name TEXT,
            role_id INTEGER DEFAULT 0,
            notifications_enabled BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (role_id) REFERENCES roles (id)
        )
    ''')
    
    # Таблица подписок на уведомления
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS telegram_subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            telegram_user_id INTEGER,
            subscribed_events TEXT,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Таблица курсов (заглушка)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            description TEXT,
            is_active BOOLEAN DEFAULT 1
        )
    ''')
    
    # Таблица заданий (заглушка)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS assignments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER,
            title TEXT,
            description TEXT,
            due_date TIMESTAMP,
            max_score INTEGER
        )
    ''')
    
    # Новая таблица для ИИ-анализа и чатов
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS ai_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            telegram_user_id INTEGER,
            session_started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            session_ended_at TIMESTAMP,
            is_active BOOLEAN DEFAULT 1,
            analysis_data TEXT,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Таблица для настроек ИИ-уведомлений
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS ai_notification_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            telegram_user_id INTEGER,
            enabled BOOLEAN DEFAULT 1,
            check_interval_hours INTEGER DEFAULT 24,
            notify_on_low_grades BOOLEAN DEFAULT 1,
            notify_on_missing_deadlines BOOLEAN DEFAULT 1,
            notify_on_inactivity BOOLEAN DEFAULT 1,
            min_grade_threshold INTEGER DEFAULT 60,
            max_inactivity_days INTEGER DEFAULT 3,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Таблица для истории ИИ-анализа
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS ai_analysis_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            analysis_type TEXT,
            analysis_data TEXT,
            recommendations TEXT,
            severity TEXT DEFAULT 'info',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Вставляем демо данные
    cursor.execute('''
        INSERT OR IGNORE INTO courses (id, title, description) 
        VALUES 
        (1, 'Математика', 'Базовый курс математики'),
        (2, 'Программирование', 'Введение в Python'),
        (3, 'Английский язык', 'Деловой английский')
    ''')
    
    cursor.execute('''
        INSERT OR IGNORE INTO assignments (course_id, title, due_date, max_score) 
        VALUES 
        (1, 'Linear Equations', '2024-12-31 23:59:59', 100),
        (2, 'Python Basics', '2024-12-25 23:59:59', 100),
        (3, 'Business Vocabulary', '2024-12-20 23:59:59', 100)
    ''')
    
    conn.commit()
    conn.close()
    logging.info("Database initialized with demo data and AI tables")

def get_db_connection():
    return sqlite3.connect(DATABASE_PATH)