import logging
import threading
import time
from telebot import TeleBot
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove, InlineKeyboardMarkup, InlineKeyboardButton

from config import BOT_TOKEN
from database import init_database, get_db_connection # Добавляем get_db_connection
from services.notification_service import NotificationService
from services.lms_api import LMSAPIService # Для получения lms_user_id

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Инициализация бота и сервисов
notification_service = NotificationService()
bot = TeleBot(BOT_TOKEN)

# Импорт хендлеров
from handlers.start import register_handlers as register_start_handlers
from handlers.role_selection import register_handlers as register_role_handlers
from handlers.courses import register_handlers as register_courses_handlers
from handlers.assignments import register_handlers as register_assignments_handlers
from handlers.notifications import register_handlers as register_notifications_handlers
from handlers.admin import register_handlers as register_admin_handlers, get_teacher_menu, get_admin_menu
from handlers.ai_analysis import register_handlers as register_ai_handlers, get_ai_menu

# Главное меню (для студента)
def main_menu():
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(
        KeyboardButton("📚 Мои курсы"),
        KeyboardButton("📝 Задания")
    )
    keyboard.add(
        KeyboardButton("⏰ Дедлайны"), 
        KeyboardButton("📊 Оценки")
    )
    keyboard.add(
        KeyboardButton("🤖 ИИ Анализ"),
        KeyboardButton("⚙️ Настройки")
    )
    keyboard.add(
        KeyboardButton("ℹ️ Помощь")
    )
    return keyboard

# Функция для показа выбора роли
def show_role_selection(chat_id):
    from handlers.role_selection import show_role_selection
    show_role_selection(bot, chat_id)

# Получить меню по роли пользователя
def get_menu_by_role(user_id):
    from handlers.admin import get_user_role
    role_id = get_user_role(user_id)
    
    if role_id == 1:  # student
        return main_menu()
    elif role_id == 2:  # teacher
        return get_teacher_menu()
    elif role_id == 3:  # admin
        return get_admin_menu()
    else:
        return main_menu()

# Регистрация всех хендлеров
def register_all_handlers():
    register_start_handlers(bot, main_menu, show_role_selection, get_menu_by_role)
    register_role_handlers(bot, main_menu, get_menu_by_role)
    register_courses_handlers(bot, get_menu_by_role)
    register_assignments_handlers(bot, get_menu_by_role)
    register_notifications_handlers(bot, get_menu_by_role)
    register_admin_handlers(bot, main_menu, get_menu_by_role)
    register_ai_handlers(bot, main_menu, get_menu_by_role)
    
    # Хендлер для обработки callback-запросов от рекомендаций
    @bot.callback_query_handler(func=lambda call: call.data.startswith('rec_done_'))
    def callback_mark_done(call):
        rec_id = int(call.data.split('_')[2])
        
        # Получаем lms_user_id из БД бота
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT lms_user_id FROM users WHERE telegram_id = ?", (call.from_user.id,))
        user_data = cursor.fetchone()
        conn.close()
        
        if not user_data:
            bot.answer_callback_query(call.id, "Ошибка: Пользователь не найден в базе бота.")
            return

        # Отправляем запрос в LMS API
        if LMSAPIService.mark_recommendation_done(rec_id):
            bot.edit_message_text(
                f"{call.message.text}\n\n*✅ Отмечено как выполненное в LMS.*",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown",
                reply_markup=None # Удаляем кнопки
            )
            bot.answer_callback_query(call.id, "Рекомендация отмечена как выполненная.")
        else:
            bot.answer_callback_query(call.id, "Ошибка при отметке рекомендации. Попробуйте позже.")

    logger.info("All handlers registered")

# --- Фоновая задача для проверки рекомендаций ---
def recommendation_checker():
    """Синхронная функция для периодической проверки новых рекомендаций в LMS."""
    while True:
        try:
            # Получаем всех пользователей из БД бота
            conn = get_db_connection()
            cursor = conn.cursor()
            # Выбираем только тех, у кого есть lms_user_id
            cursor.execute("SELECT telegram_id, lms_user_id FROM users WHERE lms_user_id IS NOT NULL")
            users = cursor.fetchall()
            conn.close()

            for telegram_id, lms_user_id in users:
                # Получаем новые рекомендации из LMS
                recommendations = LMSAPIService.get_new_recommendations(lms_user_id)
                
                if recommendations:
                    logger.info(f"Найдено {len(recommendations)} новых рекомендаций для пользователя {lms_user_id}")
                    
                    # Отправляем каждую рекомендацию
                    for rec in recommendations:
                        # Поскольку telebot синхронный, мы не можем использовать await
                        # Но мы можем использовать метод send_message напрямую
                        # Для этого нужно переделать notification_service.send_recommendation
                        # на синхронный метод, использующий self.bot.send_message
                        
                        # Временное решение: прямое использование bot.send_message
                        message = f"💡 *Интеллектуальная рекомендация:*\n\n{rec['message']}"
                        keyboard = InlineKeyboardMarkup(row_width=1)
                        
                        if rec.get('action_link'):
                            action_url = "https://example.com" + rec['action_link'] # Заглушка
                            keyboard.add(InlineKeyboardButton(text="Перейти к действию", url=action_url))
                        
                        keyboard.add(InlineKeyboardButton(text="✅ Выполнено", callback_data=f"rec_done_{rec['id']}"))

                        try:
                            bot.send_message(
                                chat_id=telegram_id,
                                text=message,
                                reply_markup=keyboard,
                                parse_mode="Markdown"
                            )
                            logger.info(f"Рекомендация {rec['id']} отправлена пользователю {telegram_id}")
                        except Exception as e:
                            logger.error(f"Ошибка при отправке рекомендации {rec['id']} пользователю {telegram_id}: {e}")

            # Пауза между проверками (например, 5 минут)
            time.sleep(300) 
        except Exception as e:
            logger.error(f"Критическая ошибка в фоновой задаче: {e}")
            time.sleep(60) # Пауза перед повторной попыткой

# Запуск бота
if __name__ == "__main__":
    init_database()
    register_all_handlers()
    
    # Запускаем фоновую задачу в отдельном потоке
    checker_thread = threading.Thread(target=recommendation_checker)
    checker_thread.daemon = True
    checker_thread.start()
    
    logger.info("🤖 Бот запущен с системой ролей, ИИ-анализом и фоновой проверкой рекомендаций!")
    bot.infinity_polling()
