import logging
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from database import get_db_connection
from services.lms_api import LMSAPIService

logger = logging.getLogger(__name__)

def register_handlers(bot, get_menu_by_role_func):
    @bot.message_handler(func=lambda message: message.text == "📚 Мои курсы")
    def show_courses(message):
        user_id = message.from_user.id
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Получаем lms_user_id из БД бота
        cursor.execute("SELECT lms_user_id FROM users WHERE telegram_id = ?", (user_id,))
        user_data = cursor.fetchone()
        conn.close()
        
        if not user_data or not user_data[0]:
            bot.send_message(
                message.chat.id,
                "❌ Ваш аккаунт не связан с LMS платформой.\n\nИспользуйте команду /start для привязки аккаунта.",
                reply_markup=get_menu_by_role_func(user_id)
            )
            return
        
        lms_user_id = user_data[0]
        
        # Получаем курсы из LMS API
        courses = LMSAPIService.get_user_courses(lms_user_id)
        
        if not courses:
            bot.send_message(
                message.chat.id, 
                "📚 У вас пока нет активных курсов.",
                reply_markup=get_menu_by_role_func(user_id)
            )
            return
        
        text = "📚 *Ваши активные курсы:*\n\n"
        keyboard = InlineKeyboardMarkup()
        
        for course in courses:
            text += f"🎯 *{course['title']}*\n"
            if course.get('description'):
                text += f"📖 {course['description'][:100]}...\n"
            text += f"👨‍🏫 Преподаватель: {course.get('teacher_name', 'Не указан')}\n\n"
            
            keyboard.add(InlineKeyboardButton(
                text=f"Открыть {course['title']}", 
                callback_data=f"course_{course['id']}"
            ))
        
        # Добавляем кнопку возврата в главное меню
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard, parse_mode="Markdown")

    @bot.callback_query_handler(func=lambda call: call.data.startswith('course_'))
    def show_course_detail(call):
        course_id = call.data.split('_')[1]
        user_id = call.from_user.id
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT lms_user_id FROM users WHERE telegram_id = ?", (user_id,))
        user_data = cursor.fetchone()
        conn.close()
        
        if not user_data or not user_data[0]:
            bot.answer_callback_query(call.id, "Ошибка: аккаунт не связан с LMS")
            return
        
        lms_user_id = user_data[0]
        
        # Получаем информацию о курсе
        courses = LMSAPIService.get_user_courses(lms_user_id)
        course = next((c for c in courses if c['id'] == int(course_id)), None)
        
        if not course:
            bot.answer_callback_query(call.id, "Курс не найден")
            return
        
        # Получаем задания курса
        all_assignments = LMSAPIService.get_user_assignments(lms_user_id)
        course_assignments = [a for a in all_assignments if a.get('course_title') == course['title']]
        
        text = f"""
🎯 *{course['title']}*

📖 {course.get('description', 'Описание отсутствует')}

👨‍🏫 Преподаватель: {course.get('teacher_name', 'Не указан')}

📝 *Активные задания:* {len(course_assignments)}
"""
        
        if course_assignments:
            text += "\n"
            for assignment in course_assignments[:3]:  # Показываем первые 3
                status_emoji = {
                    'not_submitted': '⏳',
                    'submitted': '📤',
                    'graded': '✅',
                    'under_review': '🔍'
                }.get(assignment.get('status', 'not_submitted'), '❓')
                
                text += f"{status_emoji} {assignment['title']}\n"
        
        text += "\n🚀 Используйте веб-платформу для полного доступа к материалам!"
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(text="📋 Задания курса", callback_data=f"course_assignments_{course_id}"))
        keyboard.add(InlineKeyboardButton(text="🌐 Открыть в веб-интерфейсе", url=f"http://127.0.0.1:5000/course/{course_id}"))
        
        # Добавляем кнопку возврата в главное меню
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад к курсам",
            callback_data="back_to_courses"
        ))
        
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, 
                             reply_markup=keyboard, parse_mode="Markdown")
        bot.answer_callback_query(call.id, "Курс загружен!")

    @bot.callback_query_handler(func=lambda call: call.data == "back_to_courses")
    def back_to_courses(call):
        """Обработчик возврата к списку курсов"""
        # Имитируем нажатие кнопки "Мои курсы"
        from telebot.types import Message
        fake_message = Message(
            message_id=call.message.message_id,
            from_user=call.from_user,
            date=call.message.date,
            chat=call.message.chat,
            content_type='text',
            options={'text': '📚 Мои курсы'},
            json_string=''
        )
        fake_message.text = '📚 Мои курсы'
        show_courses(fake_message)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "main_menu")
    def back_to_main_menu(call):
        """Обработчик возврата в главное меню"""
        user_id = call.from_user.id
        bot.send_message(
            call.message.chat.id,
            "⬅️ Возврат в главное меню",
            reply_markup=get_menu_by_role_func(user_id)
        )
        bot.answer_callback_query(call.id)
