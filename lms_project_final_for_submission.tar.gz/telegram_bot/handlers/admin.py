import logging
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from database import get_db_connection

logger = logging.getLogger(__name__)

def get_user_role(user_id):
    """Получить роль пользователя"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT role_id FROM users WHERE telegram_id = ?",
        (user_id,)
    )
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else 1

def get_teacher_menu():
    """Меню для преподавателя"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(
        KeyboardButton("📚 Мои курсы"),
        KeyboardButton("📝 Проверка работ")
    )
    keyboard.add(
        KeyboardButton("📊 Статистика"),
        KeyboardButton("👥 Группы")
    )
    keyboard.add(
        KeyboardButton("📢 Создать объявление"),
        KeyboardButton("⚙️ Настройки")
    )
    keyboard.add(
        KeyboardButton("🎓 Режим студента")
    )
    return keyboard

def get_admin_menu():
    """Меню для администратора"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(
        KeyboardButton("📊 Общая статистика"),
        KeyboardButton("👥 Управление пользователями")
    )
    keyboard.add(
        KeyboardButton("🏫 Управление курсами"),
        KeyboardButton("⚙️ Системные настройки")
    )
    keyboard.add(
        KeyboardButton("📢 Рассылка"),
        KeyboardButton("🔧 Тех. поддержка")
    )
    keyboard.add(
        KeyboardButton("🎓 Режим студента"),
        KeyboardButton("👨‍🏫 Режим преподавателя")
    )
    return keyboard

def register_handlers(bot, main_menu_func, get_menu_by_role_func):
    @bot.message_handler(func=lambda message: message.text == "🎓 Режим студента")
    def switch_to_student(message):
        """Переключиться в режим студента"""
        user_id = message.from_user.id
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE users SET role_id = 1 WHERE telegram_id = ?",
            (user_id,)
        )
        conn.commit()
        conn.close()
        
        bot.send_message(
            message.chat.id,
            "✅ Переключен в режим студента",
            reply_markup=main_menu_func(user_id)
        )

    @bot.message_handler(func=lambda message: message.text == "👨‍🏫 Режим преподавателя")
    def switch_to_teacher(message):
        """Переключиться в режим преподавателя"""
        user_id = message.from_user.id
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE users SET role_id = 2 WHERE telegram_id = ?",
            (user_id,)
        )
        conn.commit()
        conn.close()
        
        bot.send_message(
            message.chat.id,
            "✅ Переключен в режим преподавателя",
            reply_markup=get_menu_by_role_func(user_id)
        )

    # Обработчики для преподавателя
    @bot.message_handler(func=lambda message: get_user_role(message.from_user.id) in [2, 3] and message.text == "📝 Проверка работ")
    def show_review_queue(message):
        text = """
📝 Очередь на проверку:

1. Иванов Иван - Линейные уравнения
   ⏰ Отправлено: 2 часа назад
   📚 Курс: Математика
   🔴 Приоритет: Высокий

2. Петрова Мария - Python функции
   ⏰ Отправлено: 5 часов назад  
   📚 Курс: Программирование
   🟡 Приоритет: Средний

3. Сидоров Алексей - Business email
   ⏰ Отправлено: 1 день назад
   📚 Курс: Английский язык
   🟢 Приоритет: Низкий

Всего работ в очереди: 5
        """
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(text="🔍 Проверить следующую работу", callback_data="review_next"))
        keyboard.add(InlineKeyboardButton(text="📊 Статистика проверок", callback_data="review_stats"))
        keyboard.add(InlineKeyboardButton(text="🌐 Открыть в веб-интерфейсе", url="https://lms-platform.com/review"))
        
        # Добавляем кнопку возврата в главное меню
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)

    @bot.message_handler(func=lambda message: get_user_role(message.from_user.id) in [2, 3] and message.text == "📊 Статистика")
    def show_teacher_stats(message):
        text = """
📊 Статистика преподавателя:

👥 Общая информация:
• Студентов: 45
• Активных курсов: 3
• Средняя успеваемость: 78%

📈 По курсам:
• Математика: 82% (36 студентов)
• Программирование: 75% (42 студента)  
• Английский: 77% (38 студентов)

⏰ На этой неделе:
• Проверено работ: 23
• Среднее время проверки: 2.5 часа
• Ожидает проверки: 5
        """
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)

    @bot.message_handler(func=lambda message: get_user_role(message.from_user.id) in [2, 3] and message.text == "👥 Группы")
    def show_groups(message):
        text = """
👥 Ваши группы:

1. Группа МАТ-21-1 (Математика)
   👤 Студентов: 24
   📊 Средний балл: 82%
   🔔 Активных: 22

2. Группа ПРОГ-21-1 (Программирование)
   👤 Студентов: 28  
   📊 Средний балл: 75%
   🔔 Активных: 25

3. Группа АНГ-21-1 (Английский)
   👤 Студентов: 20
   📊 Средний балл: 77%
   🔔 Активных: 18
        """
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(text="📋 Список студентов", callback_data="student_list"))
        keyboard.add(InlineKeyboardButton(text="📤 Экспорт оценок", callback_data="export_grades"))
        keyboard.add(InlineKeyboardButton(text="📝 Создать группу", callback_data="create_group"))
        
        # Добавляем кнопку возврата в главное меню
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)

    @bot.message_handler(func=lambda message: get_user_role(message.from_user.id) in [2, 3] and message.text == "📢 Создать объявление")
    def create_announcement(message):
        text = """
📢 Создание объявления

Выберите тип объявления:
        """
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(text="📚 Для курса", callback_data="announce_course"))
        keyboard.add(InlineKeyboardButton(text="👥 Для группы", callback_data="announce_group"))
        keyboard.add(InlineKeyboardButton(text="📢 Для всех", callback_data="announce_all"))
        
        # Добавляем кнопку возврата в главное меню
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)

    # Обработчики для администратора
    @bot.message_handler(func=lambda message: get_user_role(message.from_user.id) == 3 and message.text == "📊 Общая статистика")
    def show_admin_stats(message):
        text = """
⚡ Статистика платформы (Админ)

👥 Пользователи:
• Всего: 1,247
• Студентов: 1,156
• Преподавателей: 78
• Администраторов: 13

📚 Курсы:
• Активных: 47
• Завершенных: 23
• В разработке: 8

📈 Активность:
• Онлайн сейчас: 89
• Новых работ за день: 156
• Проверено работ: 128

🛠 Система:
• Нагрузка: 24%
• Свободно места: 78%
• Последний бэкап: 2 часа назад
        """
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)

    @bot.message_handler(func=lambda message: get_user_role(message.from_user.id) == 3 and message.text == "👥 Управление пользователями")
    def manage_users(message):
        text = """
👥 Управление пользователями

Действия с пользователями:
        """
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(text="📋 Список пользователей", callback_data="admin_user_list"))
        keyboard.add(InlineKeyboardButton(text="➕ Добавить пользователя", callback_data="admin_add_user"))
        keyboard.add(InlineKeyboardButton(text="🔄 Изменить роль", callback_data="admin_change_role"))
        keyboard.add(InlineKeyboardButton(text="📊 Статистика активности", callback_data="admin_activity_stats"))
        
        # Добавляем кнопку возврата в главное меню
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)

    @bot.callback_query_handler(func=lambda call: call.data == "review_next")
    def review_next_work(call):
        """Проверить следующую работу"""
        text = """
🔍 Проверка работы:

Студент: Иванов Иван
Задание: Линейные уравнения
Курс: Математика

📄 Работа:
Решил систему уравнений:
2x + 3y = 12
x - y = 1

Решение:
x = 3, y = 2

💬 Комментарий студента:
"Постарался решить самостоятельно"

📝 Ваша оценка:
        """
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(
            InlineKeyboardButton(text="✅ Принять (95/100)", callback_data="grade_95"),
            InlineKeyboardButton(text="🟡 На доработку", callback_data="grade_revision")
        )
        keyboard.add(InlineKeyboardButton(text="💬 Добавить комментарий", callback_data="add_comment"))
        keyboard.add(InlineKeyboardButton(text="⏭ Пропустить", callback_data="skip_work"))
        
        # Добавляем кнопку возврата в главное меню
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(call.message.chat.id, text, reply_markup=keyboard)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "main_menu")
    def back_to_main_menu(call):
        """Обработчик возврата в главное меню"""
        user_id = call.from_user.id
        bot.send_message(
            call.message.chat.id,
            "⬅️ Возврат в главное меню",
            reply_markup=get_menu_by_role_func(user_id)
        )
        bot.answer_callback_query(call.id)

    # Дополнительные обработчики для callback кнопок
    @bot.callback_query_handler(func=lambda call: call.data in ["review_stats", "student_list", "export_grades", "create_group", 
                                                               "announce_course", "announce_group", "announce_all",
                                                               "admin_user_list", "admin_add_user", "admin_change_role", "admin_activity_stats"])
    def handle_admin_callbacks(call):
        """Обработчик для административных callback кнопок"""
        action_texts = {
            "review_stats": "📊 Статистика проверок будет показана здесь...",
            "student_list": "📋 Список студентов будет показан здесь...",
            "export_grades": "📤 Экспорт оценок будет выполнен...",
            "create_group": "📝 Создание новой группы...",
            "announce_course": "📚 Создание объявления для курса...",
            "announce_group": "👥 Создание объявления для группы...",
            "announce_all": "📢 Создание общего объявления...",
            "admin_user_list": "📋 Список пользователей (админ)...",
            "admin_add_user": "➕ Добавление пользователя (админ)...",
            "admin_change_role": "🔄 Изменение роли пользователя (админ)...",
            "admin_activity_stats": "📊 Статистика активности (админ)..."
        }
        
        text = action_texts.get(call.data, "Действие выполняется...")
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(call.message.chat.id, text, reply_markup=keyboard)
        bot.answer_callback_query(call.id)