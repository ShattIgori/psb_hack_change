import logging
from database import get_db_connection
from telebot.types import ReplyKeyboardRemove, ReplyKeyboardMarkup, KeyboardButton

logger = logging.getLogger(__name__)

def register_handlers(bot, main_menu_func, show_role_selection_func, get_menu_by_role_func):
    @bot.message_handler(commands=['start'])
    def start_command(message):
        user = message.from_user
        full_name = f"{user.first_name} {user.last_name or ''}".strip()
        
        # Получаем текущую роль и LMS ID пользователя
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT role_id, lms_user_id FROM users WHERE telegram_id = ?",
            (user.id,)
        )
        user_data = cursor.fetchone()
        
        if not user_data:
            # Новый пользователь - вставляем с ролью 0 (не выбрана)
            # Добавляем временный LMS_USER_ID для связки
            lms_user_id = 1 # Временная заглушка, в реале нужно получить из LMS
            
            cursor.execute(
                "INSERT INTO users (telegram_id, full_name, role_id, lms_user_id) VALUES (?, ?, 0, ?)",
                (user.id, full_name, lms_user_id)
            )
            conn.commit()
            role_id = 0
        else:
            role_id = user_data[0]
            lms_user_id = user_data[1]
            
        conn.close()
        
        # Если роль не выбрана (0)
        if role_id == 0:
            # Убираем все ReplyKeyboardMarkup и показываем выбор роли (InlineKeyboardMarkup)
            bot.send_message(message.chat.id, "Привет! Для начала работы выберите вашу роль.", reply_markup=ReplyKeyboardRemove())
            show_role_selection_func(message.chat.id)
        else:
            # Показываем приветствие с текущей ролью
            role_names = {
                1: "🎓 студента",
                2: "👨‍🏫 преподавателя", 
                3: "⚡ администратора"
            }
            
            welcome_text = f"""
👋 Привет, {full_name}!

🤖 Добро пожаловать в режим {role_names.get(role_id, 'неизвестной роли')} LMS платформы.

🚀 Используй кнопки ниже для доступа к функциям!
            """
            
            bot.send_message(message.chat.id, welcome_text, reply_markup=get_menu_by_role_func(user.id))

    @bot.message_handler(func=lambda message: message.text == "🔙 Главное меню")
    def back_to_main_menu(message):
        """Возврат в главное меню"""
        user_id = message.from_user.id
        bot.send_message(
            message.chat.id, 
            "🏡 Возвращаю в главное меню.", 
            reply_markup=get_menu_by_role_func(user_id)
        )

    @bot.message_handler(commands=['help'])
    def help_command(message):
        help_text = """
📖 Доступные команды:

/start - Перезапустить бота
/role - Сменить роль
/courses - Мои курсы
/assignments - Задания
/deadlines - Дедлайны
/notifications - Настройки уведомлений
/help - Помощь

📱 Или используй кнопки меню!

👨‍🏫 Для преподавателей и администраторов доступны дополнительные функции.
        """
        bot.send_message(message.chat.id, help_text)