import logging
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardRemove
from database import get_db_connection

logger = logging.getLogger(__name__)

def show_role_selection(bot, chat_id):
    """Показать выбор роли"""
    text = "👤 Выберите вашу роль:"
    
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("🎓 Я студент", callback_data="role_student"))
    keyboard.add(InlineKeyboardButton("👨‍🏫 Я преподаватель", callback_data="role_teacher"))
    keyboard.add(InlineKeyboardButton("⚡ Я администратор", callback_data="role_admin"))
    
    bot.send_message(chat_id, text, reply_markup=keyboard)

def register_handlers(bot, main_menu_func, get_menu_by_role_func):
    @bot.message_handler(commands=['role'])
    def select_role(message):
        """Команда для смены роли"""
        show_role_selection(bot, message.chat.id)

    @bot.callback_query_handler(func=lambda call: call.data.startswith('role_'))
    def handle_role_selection(call):
        """Обработка выбора роли"""
        role_type = call.data.split('_')[1]
        user_id = call.from_user.id
        
        role_map = {
            'student': 1,
            'teacher': 2, 
            'admin': 3
        }
        
        role_id = role_map.get(role_type, 1)
        
        # Обновляем роль пользователя
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE users SET role_id = ? WHERE telegram_id = ?",
            (role_id, user_id)
        )
        conn.commit()
        conn.close()
        
        role_names = {
            'student': '🎓 студента',
            'teacher': '👨‍🏫 преподавателя', 
            'admin': '⚡ администратора'
        }
        
        welcome_text = f"""
✅ Роль установлена: {role_names[role_type]}

🤖 Теперь вы можете использовать функции для этой роли.

🚀 Используйте кнопки меню для доступа к функциям!
        """
        
        # Удаляем InlineKeyboardMarkup после выбора роли
        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=welcome_text
        )
        # Отправляем новое сообщение с ReplyKeyboardMarkup
        bot.send_message(
            call.message.chat.id, 
            "Меню обновлено:",
            reply_markup=get_menu_by_role_func(user_id)
        )
        bot.answer_callback_query(call.id, "Роль изменена!")