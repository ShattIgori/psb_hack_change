import logging
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from database import get_db_connection

logger = logging.getLogger(__name__)

def register_handlers(bot, get_menu_by_role_func):
    @bot.message_handler(func=lambda message: message.text == "⚙️ Настройки")
    def show_settings(message):
        user_id = message.from_user.id
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT notifications_enabled FROM users WHERE telegram_id = ?",
            (user_id,)
        )
        user = cursor.fetchone()
        conn.close()
        
        notifications_status = "🔔 ВКЛЮЧЕНЫ" if user and user[0] else "🔕 ОТКЛЮЧЕНЫ"
        
        text = f"""
⚙️ Настройки уведомлений

Текущий статус: {notifications_status}

📨 Типы уведомлений:
✅ Новые задания
✅ Приближающиеся дедлайны
✅ Комментарии преподавателя
✅ Выставленные оценки
✅ Новые материалы курса
✅ Приглашения в курсы

Настройте получение уведомлений:
        """
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(text="🔔 Включить уведомления", callback_data="enable_notifications"))
        keyboard.add(InlineKeyboardButton(text="🔕 Отключить уведомления", callback_data="disable_notifications"))
        keyboard.add(InlineKeyboardButton(text="📋 Настроить типы уведомлений", callback_data="notification_types"))
        
        # Добавляем кнопку возврата в главное меню
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)

    @bot.callback_query_handler(func=lambda call: call.data == "enable_notifications")
    def enable_notifications(call):
        user_id = call.from_user.id
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE users SET notifications_enabled = 1 WHERE telegram_id = ?",
            (user_id,)
        )
        conn.commit()
        conn.close()
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(
            call.message.chat.id, 
            "🔔 Уведомления включены! Вы будете получать все важные обновления.",
            reply_markup=keyboard
        )
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "disable_notifications")
    def disable_notifications(call):
        user_id = call.from_user.id
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE users SET notifications_enabled = 0 WHERE telegram_id = ?",
            (user_id,)
        )
        conn.commit()
        conn.close()
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(
            call.message.chat.id, 
            "🔕 Уведомления отключены. Вы можете включить их снова в любое время.",
            reply_markup=keyboard
        )
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "notification_types")
    def show_notification_types(call):
        """Настройка типов уведомлений"""
        text = """
📋 Настройка типов уведомлений

Выберите какие уведомления вы хотите получать:

🔔 Основные уведомления:
✅ Новые задания
✅ Приближающиеся дедлайны  
✅ Выставленные оценки

📚 Уведомления курсов:
✅ Новые материалы
✅ Объявления преподавателей
✅ Изменения в расписании

💬 Социальные уведомления:
✅ Комментарии к работам
✅ Ответы на вопросы
✅ Приглашения в курсы
        """
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(text="✅ Включить все", callback_data="enable_all_types"))
        keyboard.add(InlineKeyboardButton(text="❌ Отключить все", callback_data="disable_all_types"))
        keyboard.add(InlineKeyboardButton(text="⚙️ Выборочная настройка", callback_data="custom_notifications"))
        
        # Добавляем кнопку возврата в главное меню
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(call.message.chat.id, text, reply_markup=keyboard)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "main_menu")
    def back_to_main_menu(call):
        """Обработчик возврата в главное меню"""
        user_id = call.from_user.id
        bot.send_message(
            call.message.chat.id,
            "⬅️ Возврат в главное меню",
            reply_markup=get_menu_by_role_func(user_id)
        )
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data in ["enable_all_types", "disable_all_types", "custom_notifications"])
    def handle_notification_types(call):
        """Обработчик для типов уведомлений"""
        if call.data == "enable_all_types":
            message_text = "✅ Все типы уведомлений включены!"
        elif call.data == "disable_all_types":
            message_text = "❌ Все типы уведомлений отключены!"
        else:
            message_text = "⚙️ Переход к выборочной настройке уведомлений..."
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(call.message.chat.id, message_text, reply_markup=keyboard)
        bot.answer_callback_query(call.id)