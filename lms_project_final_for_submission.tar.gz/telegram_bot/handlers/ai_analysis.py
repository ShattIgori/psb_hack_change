import logging
import json
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from database import get_db_connection
from services.ai_service import AIService

logger = logging.getLogger(__name__)

# Глобальный словарь для хранения активных сессий
active_ai_sessions = {}

def get_ai_menu():
    """Меню для ИИ-анализа"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("📊 Быстрый анализ"))
    keyboard.add(KeyboardButton("💬 Задать вопрос"))
    keyboard.add(KeyboardButton("📋 Мои рекомендации"))
    keyboard.add(KeyboardButton("⚙️ Настройки ИИ"))
    keyboard.add(KeyboardButton("🔙 Главное меню"))
    return keyboard

def get_ai_chat_menu():
    """Меню для чата с ИИ"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("🔄 Новый анализ"))
    keyboard.add(KeyboardButton("💬 Задать вопрос"))
    keyboard.add(KeyboardButton("📋 Мои рекомендации"))
    keyboard.add(KeyboardButton("🚪 Закончить чат"))
    return keyboard

def register_handlers(bot, main_menu_func, get_menu_by_role_func):
    ai_service = AIService()

    def get_user_data(user_id):
        """Получить данные пользователя для анализа"""
        # Заглушка с демо-данными
        return {
            'full_name': 'Иван Иванов',
            'role': 'student',
            'courses': [
                {'title': 'Математика', 'progress': 65, 'avg_grade': 78},
                {'title': 'Программирование', 'progress': 45, 'avg_grade': 65},
                {'title': 'Английский', 'progress': 80, 'avg_grade': 85}
            ],
            'assignments': [
                {'title': 'Linear Equations', 'status': 'completed', 'due_date': '2024-12-31'},
                {'title': 'Python Basics', 'status': 'in_progress', 'due_date': '2024-12-25'},
                {'title': 'Business Vocabulary', 'status': 'not_started', 'due_date': '2024-12-20'}
            ],
            'recent_grades': [
                {'course': 'Математика', 'score': 78},
                {'course': 'Программирование', 'score': 65},
                {'course': 'Английский', 'score': 85},
                {'course': 'Математика', 'score': 82}
            ],
            'last_activity': '2 дня назад',
            'problem_areas': ['Программирование', 'Сложные алгоритмы']
        }

    @bot.message_handler(func=lambda message: message.text == "🤖 ИИ Анализ")
    def start_ai_analysis(message):
        """Начать ИИ-анализ"""
        user_id = message.from_user.id
        
        # Создаем сессию
        active_ai_sessions[user_id] = {
            'conversation_history': [],
            'in_chat_mode': False
        }
        
        text = """
🤖 AI-поддержка от команды ПНВ

Я проанализирую вашу успеваемость и дам персонализированные рекомендации.

Выберите действие:
"""
        bot.send_message(message.chat.id, text, reply_markup=get_ai_menu())

    @bot.message_handler(func=lambda message: message.text == "📊 Быстрый анализ")
    def quick_analysis(message):
        """Быстрый анализ успеваемости"""
        user_id = message.from_user.id
        user_data = get_user_data(user_id)
        
        bot.send_message(message.chat.id, "🔍 Анализирую вашу успеваемость...")
        
        try:
            analysis_result = ai_service.analyze_student_performance(user_data)
            
            # Сохраняем анализ в БД
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO ai_analysis_history (user_id, analysis_type, analysis_data, recommendations, severity) VALUES (?, ?, ?, ?, ?)",
                (user_id, 'quick_analysis', json.dumps(user_data), json.dumps(analysis_result['recommendations']), analysis_result['severity'])
            )
            conn.commit()
            conn.close()
            
            # Отправляем анализ пользователю
            response_text = f"""
{analysis_result['analysis']}

💫 Рекомендации:
"""
            for i, recommendation in enumerate(analysis_result['recommendations'][:3], 1):
                response_text += f"{i}. {recommendation}\n"
            
            response_text += "\nХотите обсудить анализ подробнее?"
            
            keyboard = InlineKeyboardMarkup()
            keyboard.add(InlineKeyboardButton("💬 Обсудить с ИИ", callback_data="ai_chat_start"))
            keyboard.add(InlineKeyboardButton("📋 Полный отчет", callback_data="full_report"))
            keyboard.add(InlineKeyboardButton("⚙️ Настроить уведомления", callback_data="ai_settings"))
            
            # Добавляем кнопку возврата в главное меню
            keyboard.add(InlineKeyboardButton(
                text="⬅️ Назад в главное меню",
                callback_data="main_menu"
            ))
            
            bot.send_message(message.chat.id, response_text, reply_markup=keyboard)
            
        except Exception as e:
            logger.error(f"AI analysis failed: {e}")
            bot.send_message(message.chat.id, "❌ Произошла ошибка при анализе. Попробуйте позже.")

    @bot.message_handler(func=lambda message: message.text == "💬 Задать вопрос")
    def start_ai_chat(message):
        """Начать чат с ИИ"""
        user_id = message.from_user.id
        
        if user_id not in active_ai_sessions:
            active_ai_sessions[user_id] = {
                'conversation_history': [],
                'in_chat_mode': True
            }
        else:
            active_ai_sessions[user_id]['in_chat_mode'] = True
        
        text = """
💬 Режим чата с ИИ активирован

🤖 AI-поддержка от команды ПНВ готова помочь вам!

Вы можете:
• Задать вопросы по учебе
• Попросить совета по улучшению успеваемости
• Обсудить учебные проблемы
• Получить мотивацию

Просто напишите ваш вопрос или нажмите '🚪 Закончить чат' для выхода.
"""
        bot.send_message(message.chat.id, text, reply_markup=get_ai_chat_menu())

    @bot.message_handler(func=lambda message: 
                         message.from_user.id in active_ai_sessions and 
                         active_ai_sessions[message.from_user.id].get('in_chat_mode') and
                         message.text != "🚪 Закончить чат" and
                         message.text != "💬 Задать вопрос" and
                         message.text != "🔄 Новый анализ" and
                         message.text != "📋 Мои рекомендации")
    def handle_ai_chat(message):
        """Обработка сообщений в чате с ИИ"""
        user_id = message.from_user.id
        user_message = message.text
        
        # Добавляем сообщение пользователя в историю
        active_ai_sessions[user_id]['conversation_history'].append({
            "role": "user",
            "content": user_message
        })
        
        # Получаем ответ от ИИ
        try:
            ai_response = ai_service.chat_with_student(
                user_message, 
                active_ai_sessions[user_id]['conversation_history']
            )
            
            # Добавляем ответ ИИ в истории
            active_ai_sessions[user_id]['conversation_history'].append({
                "role": "assistant",
                "content": ai_response
            })
            
            # Отправляем ответ
            bot.send_message(message.chat.id, ai_response)
            
        except Exception as e:
            logger.error(f"AI chat failed: {e}")
            bot.send_message(message.chat.id, "❌ Извините, произошла ошибка. Попробуйте позже.")

    @bot.message_handler(func=lambda message: message.text == "🚪 Закончить чат")
    def end_ai_chat(message):
        """Завершить чат с ИИ"""
        user_id = message.from_user.id
        
        if user_id in active_ai_sessions:
            active_ai_sessions[user_id]['in_chat_mode'] = False
            # Очищаем историю при выходе
            active_ai_sessions[user_id]['conversation_history'] = []
        
        text = "✅ Чат с ИИ завершен. Возвращаю в главное меню."
        bot.send_message(message.chat.id, text, reply_markup=main_menu_func(user_id))

    @bot.message_handler(func=lambda message: message.text == "📋 Мои рекомендации")
    def show_recommendations(message):
        """Показать сохраненные рекомендации"""
        user_id = message.from_user.id
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT recommendations, severity, created_at FROM ai_analysis_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 1",
            (user_id,)
        )
        result = cursor.fetchone()
        conn.close()
        
        if result:
            recommendations = json.loads(result[0])
            severity = result[1]
            created_at = result[2]
            
            severity_emoji = "🔴" if severity == "critical" else "🟡" if severity == "warning" else "🟢"
            
            text = f"""
{severity_emoji} Последние рекомендации (от {created_at[:10]}):

"""
            for i, rec in enumerate(recommendations[:5], 1):
                text += f"{i}. {rec}\n"
        else:
            text = "📝 У вас пока нет сохраненных рекомендаций. Запустите анализ успеваемости."
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)

    @bot.message_handler(func=lambda message: message.text == "⚙️ Настройки ИИ")
    def ai_settings(message):
        """Настройки ИИ-уведомлений"""
        user_id = message.from_user.id
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT enabled, check_interval_hours, notify_on_low_grades, min_grade_threshold FROM ai_notification_settings WHERE user_id = ?",
            (user_id,)
        )
        result = cursor.fetchone()
        conn.close()
        
        if result:
            enabled, interval, notify_low, min_grade = result
        else:
            # Создаем настройки по умолчанию
            enabled, interval, notify_low, min_grade = 1, 24, 1, 60
        
        status = "🔔 ВКЛЮЧЕНЫ" if enabled else "🔕 ОТКЛЮЧЕНЫ"
        
        text = f"""
⚙️ Настройки ИИ-уведомлений

Статус: {status}
Интервал проверки: каждые {interval} часов
Уведомления о низких оценках: {'✅' if notify_low else '❌'}
Минимальный порог оценки: {min_grade}/100

Настройте автоматические уведомления:
"""
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(
            InlineKeyboardButton("🔔 Включить уведомления", callback_data="ai_enable"),
            InlineKeyboardButton("🔕 Отключить уведомления", callback_data="ai_disable")
        )
        keyboard.add(InlineKeyboardButton("🕐 Изменить интервал", callback_data="ai_interval"))
        keyboard.add(InlineKeyboardButton("📊 Настроить пороги", callback_data="ai_thresholds"))
        
        # Добавляем кнопку возврата в главное меню
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)

    @bot.message_handler(func=lambda message: message.text == "🔙 Главное меню")
    def back_to_main(message):
        """Вернуться в главное меню"""
        user_id = message.from_user.id
        
        # Завершаем сессию если активна
        if user_id in active_ai_sessions:
            active_ai_sessions[user_id]['in_chat_mode'] = False
        
        bot.send_message(message.chat.id, "Возвращаю в главное меню...", reply_markup=main_menu_func(user_id))

    @bot.message_handler(func=lambda message: message.text == "🔄 Новый анализ")
    def new_analysis(message):
        """Сделать новый анализ"""
        quick_analysis(message)

    # Обработчики callback для ИИ
    @bot.callback_query_handler(func=lambda call: call.data == "ai_chat_start")
    def start_chat_from_analysis(call):
        """Начать чат из анализа"""
        user_id = call.from_user.id
        start_ai_chat(call.message)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ai_'))
    def handle_ai_settings(call):
        """Обработка настроек ИИ"""
        action = call.data
        
        if action == "ai_enable":
            # Включить уведомления
            user_id = call.from_user.id
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT OR REPLACE INTO ai_notification_settings (user_id, telegram_user_id, enabled) VALUES (?, ?, 1)",
                (user_id, user_id)
            )
            conn.commit()
            conn.close()
            
            bot.send_message(call.message.chat.id, "✅ ИИ-уведомления включены")
            bot.answer_callback_query(call.id, "Уведомления включены!")
            
        elif action == "ai_disable":
            # Отключить уведомления
            user_id = call.from_user.id
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE ai_notification_settings SET enabled = 0 WHERE user_id = ?",
                (user_id,)
            )
            conn.commit()
            conn.close()
            
            bot.send_message(call.message.chat.id, "🔕 ИИ-уведомления отключены")
            bot.answer_callback_query(call.id, "Уведомления отключены!")

        # Добавляем кнопку возврата в главное меню после действий
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(call.message.chat.id, "Что дальше?", reply_markup=keyboard)

    @bot.callback_query_handler(func=lambda call: call.data == "main_menu")
    def back_to_main_menu(call):
        """Обработчик возврата в главное меню"""
        user_id = call.from_user.id
        bot.send_message(
            call.message.chat.id,
            "⬅️ Возврат в главное меню",
            reply_markup=main_menu_func(user_id)
        )
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data in ["full_report", "ai_settings", "ai_interval", "ai_thresholds"])
    def handle_ai_callbacks(call):
        """Обработчик для AI callback кнопок"""
        action_texts = {
            "full_report": "📋 Полный отчет будет сгенерирован...",
            "ai_settings": "⚙️ Переход к настройкам ИИ...",
            "ai_interval": "🕐 Изменение интервала проверки...",
            "ai_thresholds": "📊 Настройка порогов оценок..."
        }
        
        text = action_texts.get(call.data, "Действие выполняется...")
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(call.message.chat.id, text, reply_markup=keyboard)
        bot.answer_callback_query(call.id)

    # Функция для отправки автоматических уведомлений
    def send_ai_notification(user_id, analysis_result):
        """Отправить автоматическое ИИ-уведомление"""
        if analysis_result['severity'] == 'critical':
            message = f"""
🚨 КРИТИЧЕСКОЕ УВЕДОМЛЕНИЕ от ИИ-анализа

{analysis_result['analysis']}

Немедленно примите меры!
"""
        elif analysis_result['severity'] == 'warning':
            message = f"""
⚠️ ВАЖНОЕ УВЕДОМЛЕНИЕ от ИИ-анализа

{analysis_result['analysis']}

Рекомендуем обратить внимание!
"""
        else:
            message = f"""
ℹ️ ИИ-анализ успеваемости

{analysis_result['analysis']}

Продолжайте в том же духе!
"""
        
        try:
            bot.send_message(user_id, message)
            logger.info(f"AI notification sent to user {user_id}")
        except Exception as e:
            logger.error(f"Failed to send AI notification to {user_id}: {e}")