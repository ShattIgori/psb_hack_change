import logging
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

logger = logging.getLogger(__name__)

def register_handlers(bot, get_menu_by_role_func):
    @bot.message_handler(func=lambda message: message.text == "📝 Задания")
    def show_assignments(message):
        text = """
📝 Ваши текущие задания:

1. 🎯 Linear Equations
   📚 Курс: Математика
   ⏰ Дедлайн: 31.12.2024
   📊 Статус: На проверке
   💯 Макс. балл: 100

2. 🐍 Python Basics
   📚 Курс: Программирование
   ⏰ Дедлайн: 25.12.2024
   📊 Статус: Не начато
   💯 Макс. балл: 100

3. 📊 Business Vocabulary
   📚 Курс: Английский язык
   ⏰ Дедлайн: 20.12.2024
   📊 Статус: Сделано
   💯 Макс. балл: 100
        """
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(text="📋 Все задания", callback_data="all_assignments"))
        keyboard.add(InlineKeyboardButton(text="⏰ Ближайшие дедлайны", callback_data="upcoming_deadlines"))
        keyboard.add(InlineKeyboardButton(text="📊 Мои оценки", callback_data="my_grades"))
        
        # Добавляем кнопку возврата в главное меню
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)

    @bot.message_handler(func=lambda message: message.text == "⏰ Дедлайны")
    def show_deadlines(message):
        text = """
⏰ Ближайшие дедлайны:

🚨 СЕГОДНЯ:
• Тест по алгоритмам - до 23:59

⚠️ ЗАВТРА:
• Домашнее задание по математике

📅 НА ЭТОЙ НЕДЕЛЕ:
• Проект по программирование - до пятницы
• Эссе по английскому - до субботы

📌 Не откладывайте на последний момент!
        """
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)

    @bot.message_handler(func=lambda message: message.text == "📊 Оценки")
    def show_grades(message):
        text = """
📊 Ваши последние оценки:

Математика:
• Линейные уравнения: 85/100 ✅
• Квадратные уравнения: 92/100 ✅

Программирование:
• Python основы: 78/100 ✅
• Функции: Ожидает проверки ⏳

Английский язык:
• Vocabulary test: 95/100 ✅
• Grammar quiz: 88/100 ✅

📈 Средний балл: 87.6/100
        """
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)

    @bot.callback_query_handler(func=lambda call: call.data == "my_grades")
    def show_grades_callback(call):
        show_grades(call.message)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "main_menu")
    def back_to_main_menu(call):
        """Обработчик возврата в главное меню"""
        user_id = call.from_user.id
        bot.send_message(
            call.message.chat.id,
            "⬅️ Возврат в главное меню",
            reply_markup=get_menu_by_role_func(user_id)
        )
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "all_assignments")
    def show_all_assignments(call):
        """Показать все задания"""
        text = "📋 Все задания будут показаны здесь..."
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        bot.send_message(call.message.chat.id, text, reply_markup=keyboard)
        bot.answer_callback_query(call.id)

    @bot.callback_query_handler(func=lambda call: call.data == "upcoming_deadlines")
    def show_upcoming_deadlines(call):
        """Показать ближайшие дедлайны"""
        text = "⏰ Ближайшие дедлайны будут показаны здесь..."
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            text="⬅️ Назад в главное меню",
            callback_data="main_menu"
        ))
        bot.send_message(call.message.chat.id, text, reply_markup=keyboard)
        bot.answer_callback_query(call.id)