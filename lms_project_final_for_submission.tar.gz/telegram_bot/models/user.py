from dataclasses import dataclass
from typing import Optional

@dataclass
class User:
    id: int
    telegram_id: int
    lms_user_id: Optional[int]
    full_name: str
    role_id: int = 1
    role_name: str = "student"
    notifications_enabled: bool = True
    
    @classmethod
    def from_db_row(cls, row):
        role_id = row[4] if len(row) > 4 else 1
        role_name = "student" if role_id == 1 else "teacher" if role_id == 2 else "admin"
        
        return cls(
            id=row[0],
            telegram_id=row[1],
            lms_user_id=row[2],
            full_name=row[3],
            role_id=role_id,
            role_name=role_name,
            notifications_enabled=bool(row[5]) if len(row) > 5 else True
        )
    
    def is_teacher(self):
        return self.role_id == 2 or self.role_id == 3
    
    def is_admin(self):
        return self.role_id == 3
    
    def get_role_display_name(self):
        role_names = {
            1: "🎓 Студент",
            2: "👨‍🏫 Преподаватель", 
            3: "⚡ Администратор"
        }
        return role_names.get(self.role_id, "🎓 Студент")