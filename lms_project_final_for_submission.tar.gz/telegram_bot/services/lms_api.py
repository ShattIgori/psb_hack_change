import logging
import requests
import json
from config import LMS_API_BASE_URL, LMS_API_KEY

logger = logging.getLogger(__name__)

class LMSAPIService:
    """Сервис работы с LMS API"""
    
    @staticmethod
    def _get_headers():
        """Получить заголовки для API запросов"""
        return {
            "X-API-Key": LMS_API_KEY,
            "Content-Type": "application/json"
        }
    
    @staticmethod
    def _handle_request(method, url, **kwargs):
        """Обработка HTTP запроса с логированием"""
        try:
            response = requests.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {method} {url} - {e}")
            return None
    
    @staticmethod
    def get_user_by_telegram_id(telegram_id: int):
        """Получить информацию о пользователе по Telegram ID"""
        url = f"{LMS_API_BASE_URL}/user/by_telegram/{telegram_id}"
        return LMSAPIService._handle_request("GET", url, headers=LMSAPIService._get_headers())
    
    @staticmethod
    def get_user_courses(lms_user_id: int):
        """Получить курсы пользователя"""
        url = f"{LMS_API_BASE_URL}/user/{lms_user_id}/courses"
        courses = LMSAPIService._handle_request("GET", url, headers=LMSAPIService._get_headers())
        
        if courses:
            logger.info(f"LMS API: Got {len(courses)} courses for user {lms_user_id}")
            return courses
        else:
            logger.warning(f"LMS API: No courses found for user {lms_user_id}")
            return []
    
    @staticmethod
    def get_user_assignments(lms_user_id: int):
        """Получить задания пользователя"""
        url = f"{LMS_API_BASE_URL}/user/{lms_user_id}/assignments"
        assignments = LMSAPIService._handle_request("GET", url, headers=LMSAPIService._get_headers())
        
        if assignments:
            logger.info(f"LMS API: Got {len(assignments)} assignments for user {lms_user_id}")
            return assignments
        else:
            logger.warning(f"LMS API: No assignments found for user {lms_user_id}")
            return []
    
    @staticmethod
    def get_user_deadlines(lms_user_id: int):
        """Получить ближайшие дедлайны пользователя"""
        url = f"{LMS_API_BASE_URL}/user/{lms_user_id}/deadlines"
        deadlines = LMSAPIService._handle_request("GET", url, headers=LMSAPIService._get_headers())
        
        if deadlines:
            logger.info(f"LMS API: Got {len(deadlines)} deadlines for user {lms_user_id}")
            return deadlines
        else:
            return []
    
    @staticmethod
    def get_user_grades(lms_user_id: int):
        """Получить оценки студента"""
        url = f"{LMS_API_BASE_URL}/user/{lms_user_id}/grades"
        grades = LMSAPIService._handle_request("GET", url, headers=LMSAPIService._get_headers())
        
        if grades:
            logger.info(f"LMS API: Got {len(grades)} grades for user {lms_user_id}")
            return grades
        else:
            return []
    
    @staticmethod
    def get_new_recommendations(lms_user_id: int):
        """Получить новые рекомендации для пользователя из LMS API"""
        url = f"{LMS_API_BASE_URL}/recommendations/{lms_user_id}"
        recommendations = LMSAPIService._handle_request("GET", url, headers=LMSAPIService._get_headers())
        
        if recommendations:
            logger.info(f"LMS API: Got {len(recommendations)} new recommendations for user {lms_user_id}")
            return recommendations
        else:
            return []
    
    @staticmethod
    def mark_recommendation_done(rec_id: int):
        """Отметить рекомендацию как выполненную в LMS API"""
        url = f"{LMS_API_BASE_URL}/recommendation/{rec_id}/mark_done"
        result = LMSAPIService._handle_request("POST", url, headers=LMSAPIService._get_headers())
        
        if result:
            logger.info(f"LMS API: Recommendation {rec_id} marked as done")
            return True
        else:
            logger.error(f"LMS API: Failed to mark recommendation {rec_id} as done")
            return False
    
    @staticmethod
    def link_telegram_account(lms_user_id: int, telegram_id: int):
        """Связать Telegram аккаунт с LMS пользователем"""
        url = f"{LMS_API_BASE_URL}/link_telegram"
        data = {
            "user_id": lms_user_id,
            "telegram_id": telegram_id
        }
        result = LMSAPIService._handle_request("POST", url, 
                                                headers=LMSAPIService._get_headers(),
                                                json=data)
        
        if result:
            logger.info(f"LMS API: Linked telegram {telegram_id} to user {lms_user_id}")
            return result
        else:
            logger.error(f"LMS API: Failed to link telegram {telegram_id} to user {lms_user_id}")
            return None
    
    @staticmethod
    def get_user_notifications(lms_user_id: int, limit: int = 10):
        """Получить уведомления пользователя"""
        url = f"{LMS_API_BASE_URL}/user/{lms_user_id}/notifications?limit={limit}"
        notifications = LMSAPIService._handle_request("GET", url, headers=LMSAPIService._get_headers())
        
        if notifications:
            logger.info(f"LMS API: Got {len(notifications)} notifications for user {lms_user_id}")
            return notifications
        else:
            return []
    
    @staticmethod
    def health_check():
        """Проверить доступность LMS API"""
        url = f"{LMS_API_BASE_URL}/health"
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                logger.info("LMS API is healthy")
                return True
            else:
                logger.warning(f"LMS API health check failed with status {response.status_code}")
                return False
        except Exception as e:
            logger.error(f"LMS API health check failed: {e}")
            return False
