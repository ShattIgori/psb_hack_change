import requests
import json
import logging
from typing import Dict, List, Optional
from config import OPENROUTER_API_KEY, OPENROUTER_MODEL, FALLBACK_MODELS, AI_SYSTEM_PROMPT

logger = logging.getLogger(__name__)

class AIService:
    def __init__(self):
        self.api_key = OPENROUTER_API_KEY
        self.model = OPENROUTER_MODEL
        self.fallback_models = FALLBACK_MODELS.split(",")
        self.base_url = "https://openrouter.ai/api/v1/chat/completions"
    
    def _call_ai_api(self, messages: List[Dict], model: str = None) -> Optional[str]:
        """Вызов API OpenRouter"""
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://github.com/your-repo",  # Required by OpenRouter
                "X-Title": "LMS Telegram Bot"  # Optional
            }
            
            payload = {
                "model": model or self.model,
                "messages": messages,
                "temperature": 0.7,
                "max_tokens": 2000
            }
            
            response = requests.post(self.base_url, headers=headers, json=payload, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            else:
                logger.error(f"AI API error: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"AI API call failed: {e}")
            return None
    
    def analyze_student_performance(self, user_data: Dict) -> Dict:
        """Анализ успеваемости студента"""
        user_context = self._prepare_user_context(user_data)
        
        messages = [
            {"role": "system", "content": AI_SYSTEM_PROMPT},
            {"role": "user", "content": f"""
Проанализируй успеваемость студента и дай рекомендации:

{user_context}

Пожалуйста, предоставь анализ в следующем формате:
1. 📊 Текущая ситуация
2. 🚨 Что требует немедленного внимания  
3. 📝 Конкретные действия на сейчас
4. 🎯 План на ближайшее время
5. 💡 Советы по улучшению

Будь конкретен и предлагай actionable советы.
"""}
        ]
        
        # Пробуем основную модель
        analysis = self._call_ai_api(messages, self.model)
        
        # Если основная не сработала, пробуем запасные
        if not analysis:
            for fallback_model in self.fallback_models:
                analysis = self._call_ai_api(messages, fallback_model.strip())
                if analysis:
                    break
        
        if not analysis:
            analysis = self._get_fallback_analysis(user_data)
        
        return {
            "analysis": analysis,
            "recommendations": self._extract_recommendations(analysis),
            "severity": self._calculate_severity(user_data)
        }
    
    def _prepare_user_context(self, user_data: Dict) -> str:
        """Подготовка контекста пользователя для ИИ"""
        context = f"""
Студент: {user_data.get('full_name', 'Неизвестно')}
Роль: {user_data.get('role', 'student')}

Курсы и прогресс:
"""
        
        for course in user_data.get('courses', []):
            context += f"- {course.get('title')}: {course.get('progress', 0)}% прогресс, средний балл: {course.get('avg_grade', 0)}\n"
        
        context += f"\nЗадания:\n"
        for assignment in user_data.get('assignments', []):
            status_emoji = "✅" if assignment.get('status') == 'completed' else "🟡" if assignment.get('status') == 'in_progress' else "🔴"
            context += f"- {status_emoji} {assignment.get('title')}: {assignment.get('status')}, дедлайн: {assignment.get('due_date')}\n"
        
        context += f"\nПоследние оценки:\n"
        for grade in user_data.get('recent_grades', []):
            grade_emoji = "🟢" if grade.get('score', 0) >= 90 else "🟡" if grade.get('score', 0) >= 70 else "🔴"
            context += f"- {grade_emoji} {grade.get('course')}: {grade.get('score')}/100\n"
        
        context += f"\nАктивность: {user_data.get('last_activity', 'Неизвестно')}"
        context += f"\nПроблемные зоны: {', '.join(user_data.get('problem_areas', []))}"
        
        return context
    
    def _get_fallback_analysis(self, user_data: Dict) -> str:
        """Запасной анализ если ИИ недоступен"""
        avg_grade = self._calculate_average_grade(user_data)
        
        if avg_grade >= 85:
            return """
🤖 AI-поддержка от команды ПНВ

📊 Текущая ситуация: Отличная успеваемость! Средний балл высокий.

🚨 Что требует немедленного внимания: Поддерживайте текущий темп.

📝 Конкретные действия на сейчас: Помогите одногруппникам, поделитесь знаниями.

🎯 План на ближайшее время: Углубитесь в сложные темы курсов.

💡 Советы по улучшению: Рассмотрите участие в олимпиадах или дополнительных проектах.
"""
        elif avg_grade >= 70:
            return """
🤖 AI-поддержка от команды ПНВ

📊 Текущая ситуация: Хорошая успеваемость, есть потенциал для роста.

🚨 Что требует немедленного внимания: Обратите внимание на предметы с оценками ниже 75.

📝 Конкретные действия на сейчас: Повторите материалы по самым слабым темам.

🎯 План на ближайшее время: Составьте график повторения проблемных тем.

💡 Советы по улучшению: Регулярно делайте небольшие повторения.
"""
        else:
            return """
🤖 AI-поддержка от команды ПНВ

📊 Текущая ситуация: Требуется улучшение успеваемости.

🚨 Что требует немедленного внимания: Низкие оценки по нескольким предметам.

📝 Конкретные действия на сейчас: Обратитесь к преподавателям за помощью.

🎯 План на ближайшее время: Интенсивная работа над отставанием.

💡 Советы по улучшению: Составьте четкий учебный план и следуйте ему.
"""
    
    def _calculate_average_grade(self, user_data: Dict) -> float:
        """Расчет среднего балла"""
        grades = [grade.get('score', 0) for grade in user_data.get('recent_grades', [])]
        return sum(grades) / len(grades) if grades else 0
    
    def _extract_recommendations(self, analysis: str) -> List[str]:
        """Извлечение рекомендаций из анализа"""
        # Упрощенная логика извлечения рекомендаций
        lines = analysis.split('\n')
        recommendations = []
        for line in lines:
            if '•' in line or '- ' in line or 'рекомендац' in line.lower():
                clean_line = line.replace('•', '').replace('-', '').strip()
                if clean_line and len(clean_line) > 10:
                    recommendations.append(clean_line)
        return recommendations[:5] if recommendations else ["Регулярно повторяйте материал", "Следите за дедлайнами"]
    
    def _calculate_severity(self, user_data: Dict) -> str:
        """Определение серьезности ситуации"""
        avg_grade = self._calculate_average_grade(user_data)
        
        if avg_grade < 60:
            return "critical"
        elif avg_grade < 75:
            return "warning" 
        else:
            return "info"
    
    def chat_with_student(self, message: str, conversation_history: List[Dict]) -> str:
        """Чат с студентом"""
        messages = [
            {"role": "system", "content": AI_SYSTEM_PROMPT + "\n\nТы сейчас в режиме чата со студентом. Отвечай на вопросы, давай советы по учебе, помогай с учебными проблемами."},
        ]
        
        # Добавляем историю сообщений
        messages.extend(conversation_history[-10:])  # Берем последние 10 сообщений
        
        # Добавляем текущее сообщение
        messages.append({"role": "user", "content": message})
        
        response = self._call_ai_api(messages, self.model)
        
        if not response:
            response = "🤖 Извините, в данный момент я недоступен. Пожалуйста, попробуйте позже или обратитесь к преподавателю."
        
        return response